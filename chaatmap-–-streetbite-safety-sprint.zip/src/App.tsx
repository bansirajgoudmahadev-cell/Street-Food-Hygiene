import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ExplorePage } from './pages/ExplorePage';
import { MapPage } from './pages/MapPage';
import { VendorDetailsPage } from './pages/VendorDetailsPage';
import { SubmitReviewPage } from './pages/SubmitReviewPage';
import { FoodTrailsPage } from './pages/FoodTrailsPage';
import { VendorOfTheMonthPage } from './pages/VendorOfTheMonthPage';
import { AboutPage } from './pages/AboutPage';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-[#1C1917]">
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/explore" element={<ExplorePage />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/vendors/:id" element={<VendorDetailsPage />} />
            <Route path="/review" element={<SubmitReviewPage />} />
            <Route path="/review/:vendorId" element={<SubmitReviewPage />} />
            <Route path="/trails" element={<FoodTrailsPage />} />
            <Route path="/vendor-of-the-month" element={<VendorOfTheMonthPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route
              path="*"
              element={
                <div className="max-w-3xl mx-auto px-4 py-20 text-center space-y-4">
                  <h1 className="font-display text-3xl font-bold text-[#1C1917]">
                    Page Not Found
                  </h1>
                  <p className="text-sm text-[#57534E]">
                    The ChaatMap route you requested does not exist.
                  </p>
                  <a
                    href="/"
                    className="inline-block px-5 py-2.5 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg"
                  >
                    Return Home
                  </a>
                </div>
              }
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
