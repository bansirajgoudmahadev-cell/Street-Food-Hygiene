import {
  AvailabilityStatus,
  CommunityStats,
  FeaturedVendorResponse,
  FoodTrail,
  HygieneReview,
  Vendor,
  VendorPhoto,
} from '../types/chaatmap';

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  let data: any = null;
  try {
    data = await response.json();
  } catch {
    // Non-JSON response fallback
  }

  if (!response.ok) {
    throw new Error(data?.error || `Request failed with status ${response.status}`);
  }
  return data as T;
}

export interface VendorFilterParams {
  locality?: string;
  cuisine?: string;
  minHygiene?: number;
  fssaiOnly?: boolean;
  search?: string;
  sort?: 'hygiene' | 'price_asc' | 'price_desc' | 'popularity';
}

export async function fetchVendors(params: VendorFilterParams = {}): Promise<Vendor[]> {
  const query = new URLSearchParams();
  if (params.locality && params.locality !== 'All') query.set('locality', params.locality);
  if (params.cuisine && params.cuisine !== 'All') query.set('cuisine', params.cuisine);
  if (params.minHygiene && params.minHygiene > 0) query.set('minHygiene', String(params.minHygiene));
  if (params.fssaiOnly) query.set('fssaiOnly', 'true');
  if (params.search && params.search.trim()) query.set('search', params.search.trim());
  if (params.sort) query.set('sort', params.sort);

  const qs = query.toString();
  const data = await requestJson<{ count: number; vendors: Vendor[] }>(`/api/vendors${qs ? `?${qs}` : ''}`);
  return data.vendors;
}

export async function fetchNearbyVendors(lat: number, lng: number, radiusKm = 15): Promise<Vendor[]> {
  const query = new URLSearchParams({
    lat: String(lat),
    lng: String(lng),
    radiusKm: String(radiusKm),
  });
  const data = await requestJson<{ vendors: Vendor[] }>(`/api/vendors/nearby?${query.toString()}`);
  return data.vendors;
}

export async function fetchVendorDetails(id: number): Promise<{
  vendor: Vendor;
  reviews: HygieneReview[];
  photos: VendorPhoto[];
}> {
  return requestJson(`/api/vendors/${id}`);
}

export async function submitHygieneReview(
  vendorId: number,
  payload: {
    reviewer_name: string;
    water_cleanliness: number;
    covered_food: number;
    glove_usage: number;
    surroundings: number;
    observation: string;
    photo?: File | null;
  }
): Promise<{ message: string; review: HygieneReview; vendor: Vendor }> {
  const formData = new FormData();
  formData.append('reviewer_name', payload.reviewer_name);
  formData.append('water_cleanliness', String(payload.water_cleanliness));
  formData.append('covered_food', String(payload.covered_food));
  formData.append('glove_usage', String(payload.glove_usage));
  formData.append('surroundings', String(payload.surroundings));
  formData.append('observation', payload.observation);
  if (payload.photo) {
    formData.append('photo', payload.photo);
  }

  return requestJson(`/api/vendors/${vendorId}/reviews`, {
    method: 'POST',
    body: formData,
  });
}

export async function updateVendorAvailability(
  vendorId: number,
  payload: {
    availability_status: AvailabilityStatus;
    landmark?: string;
    latitude?: number;
    longitude?: number;
  }
): Promise<{ message: string; vendor: Vendor }> {
  return requestJson(`/api/vendors/${vendorId}/availability`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function uploadVendorPhoto(
  vendorId: number,
  photo: File,
  caption: string
): Promise<{ message: string; photo: VendorPhoto }> {
  const formData = new FormData();
  formData.append('photo', photo);
  formData.append('caption', caption);
  return requestJson(`/api/vendors/${vendorId}/photos`, {
    method: 'POST',
    body: formData,
  });
}

export async function fetchFoodTrails(): Promise<FoodTrail[]> {
  const data = await requestJson<{ count: number; trails: FoodTrail[] }>('/api/trails');
  return data.trails;
}

export async function fetchCommunityStats(): Promise<CommunityStats> {
  return requestJson('/api/stats');
}

export async function fetchFeaturedVendor(): Promise<FeaturedVendorResponse> {
  return requestJson('/api/featured-vendor');
}
