import { FoodTrail } from '../types/chaatmap';

const STORAGE_KEY = 'chaatmap_offline_trails_v1';

export interface OfflineSavedTrail {
  id: number;
  name: string;
  locality: string;
  description: string;
  estimated_duration: string;
  average_hygiene_score: number;
  saved_at: string;
  vendors: {
    id: number;
    sequence_order: number;
    name: string;
    locality: string;
    address: string;
    landmark: string;
    latitude: number;
    longitude: number;
    hygiene_score: number;
    fssai_verified: boolean;
    opening_time: string;
    closing_time: string;
    price_min: number;
    price_max: number;
    dishes: { dish_name: string; price: number }[];
  }[];
}

export function getOfflineTrails(): OfflineSavedTrail[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function isTrailSavedOffline(trailId: number): boolean {
  return getOfflineTrails().some((t) => t.id === trailId);
}

export function saveTrailOffline(trail: FoodTrail): OfflineSavedTrail[] {
  const existing = getOfflineTrails().filter((t) => t.id !== trail.id);
  const snapshot: OfflineSavedTrail = {
    id: trail.id,
    name: trail.name,
    locality: trail.locality,
    description: trail.description,
    estimated_duration: trail.estimated_duration,
    average_hygiene_score: trail.average_hygiene_score,
    saved_at: new Date().toISOString(),
    vendors: trail.vendors.map((v) => ({
      id: v.id,
      sequence_order: v.sequence_order,
      name: v.name,
      locality: v.locality,
      address: v.address,
      landmark: v.landmark,
      latitude: v.latitude,
      longitude: v.longitude,
      hygiene_score: v.hygiene_score,
      fssai_verified: v.fssai_verified,
      opening_time: v.opening_time,
      closing_time: v.closing_time,
      price_min: v.price_min,
      price_max: v.price_max,
      dishes: v.dishes.map((d) => ({ dish_name: d.dish_name, price: d.price })),
    })),
  };

  const updated = [snapshot, ...existing];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
}

export function removeOfflineTrail(trailId: number): OfflineSavedTrail[] {
  const updated = getOfflineTrails().filter((t) => t.id !== trailId);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
}
