export interface FactorInput {
  water_cleanliness: number;
  covered_food: number;
  glove_usage: number;
  surroundings: number;
}

export const HYGIENE_WEIGHTS = {
  water_cleanliness: 0.40,
  covered_food: 0.25,
  glove_usage: 0.20,
  surroundings: 0.15,
} as const;

export interface HygieneFactorDefinition {
  key: keyof FactorInput;
  label: string;
  shortLabel: string;
  weightPercent: number;
  description: string;
  rubricLow: string;
  rubricHigh: string;
}

export const HYGIENE_FACTOR_META: HygieneFactorDefinition[] = [
  {
    key: 'water_cleanliness',
    label: 'Clean / RO Water Used',
    shortLabel: 'Water Cleanliness',
    weightPercent: 40,
    description: 'Purified RO or sealed mineral water used for pani, chutneys, ice, and utensil rinsing.',
    rubricLow: 'Unfiltered tap/drum water or unclear source',
    rubricHigh: 'Visible RO dispenser or sealed packaged water cans',
  },
  {
    key: 'covered_food',
    label: 'Covered Food Display',
    shortLabel: 'Covered Food',
    weightPercent: 25,
    description: 'Glass sneeze guards, tight steel lids, or mesh covers shielding ingredients from dust and insects.',
    rubricLow: 'Exposed trays near open traffic dust',
    rubricHigh: 'Full glass sneeze shield & lidded chutney canisters',
  },
  {
    key: 'glove_usage',
    label: 'Glove & Headgear Usage',
    shortLabel: 'Gloves & Headgear',
    weightPercent: 20,
    description: 'Use of food-grade gloves, serving tongs, hairnets/caps, and clean aprons while plating.',
    rubricLow: 'Bare-hand contact with ready-to-eat items',
    rubricHigh: 'Consistent gloves/tongs, hairnet, and clean apron',
  },
  {
    key: 'surroundings',
    label: 'Surroundings Cleanliness',
    shortLabel: 'Surroundings',
    weightPercent: 15,
    description: 'Clean footpath perimeter, covered waste bin, dry ground, and wiped stainless steel surfaces.',
    rubricLow: 'Littered pavement or stagnant water nearby',
    rubricHigh: 'Spotless counter, dry walkway, covered bin',
  },
];

/**
 * Exact project formula:
 * Hygiene Score = (0.40 * Water) + (0.25 * Covered Food) + (0.20 * Gloves) + (0.15 * Surroundings)
 */
export function calculateHygieneTrustScore(factors: FactorInput): number {
  const raw =
    HYGIENE_WEIGHTS.water_cleanliness * factors.water_cleanliness +
    HYGIENE_WEIGHTS.covered_food * factors.covered_food +
    HYGIENE_WEIGHTS.glove_usage * factors.glove_usage +
    HYGIENE_WEIGHTS.surroundings * factors.surroundings;
  return Math.round(raw * 100) / 100;
}

export function formatScore(score: number): string {
  if (!score) return '0.0';
  return score.toFixed(1);
}

export function formatTime12h(hhmm: string): string {
  if (!hhmm || !hhmm.includes(':')) return hhmm;
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  if (Number.isNaN(h)) return hhmm;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${mStr} ${suffix}`;
}

export function formatRelativeTime(isoString: string): string {
  if (!isoString) return 'Update time unavailable';
  const parsed = new Date(isoString);
  if (Number.isNaN(parsed.getTime())) return 'Update time unavailable';

  const diffMs = Date.now() - parsed.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 30) return `${diffDays}d ago`;
  return parsed.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function isAvailabilityStale(isoString: string): boolean {
  const parsed = new Date(isoString);
  if (Number.isNaN(parsed.getTime())) return true;
  const hoursOld = (Date.now() - parsed.getTime()) / (1000 * 60 * 60);
  return hoursOld > 24;
}
