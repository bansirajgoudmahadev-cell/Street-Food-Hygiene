export type AvailabilityStatus = 'Open' | 'Closed' | 'Unknown';

export interface Dish {
  id: number;
  vendor_id: number;
  dish_name: string;
  price: number;
  description: string;
}

export interface HygieneFactors {
  water_cleanliness: number;
  covered_food: number;
  glove_usage: number;
  surroundings: number;
  hygiene_score: number;
  review_count: number;
}

export interface Vendor {
  id: number;
  name: string;
  description: string;
  locality: string;
  address: string;
  landmark: string;
  latitude: number;
  longitude: number;
  cuisine: string;
  price_min: number;
  price_max: number;
  opening_time: string;
  closing_time: string;
  image: string;
  fssai_verified: boolean;
  availability_status: AvailabilityStatus;
  availability_updated_at: string;
  is_pushcart: boolean;
  created_at: string;
  hygiene_score: number;
  review_count: number;
  hygiene_factors: HygieneFactors;
  dishes: Dish[];
  signature_dish: string;
  distance_km?: number;
}

export interface HygieneReview {
  id: number;
  vendor_id: number;
  reviewer_name: string;
  water_cleanliness: number;
  glove_usage: number;
  covered_food: number;
  surroundings: number;
  observation: string;
  photo: string;
  created_at: string;
}

export interface VendorPhoto {
  id: number;
  vendor_id: number;
  photo_url: string;
  caption: string;
  created_at: string;
}

export interface TrailStopVendor extends Vendor {
  sequence_order: number;
}

export interface FoodTrail {
  id: number;
  name: string;
  locality: string;
  description: string;
  estimated_duration: string;
  vendor_count: number;
  average_hygiene_score: number;
  vendors: TrailStopVendor[];
}

export interface CommunityStats {
  total_vendors: number;
  total_reviews: number;
  verified_vendors: number;
  total_trails: number;
  localities: string[];
  cuisines: string[];
}

export interface FeaturedVendorResponse {
  recognition_month: string;
  minimum_review_threshold: number;
  selection_rule: string;
  qualifying_count: number;
  vendor: Vendor | null;
  runners_up: Vendor[];
}
