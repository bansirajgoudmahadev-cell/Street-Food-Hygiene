import { HygieneFactors } from '../types/chaatmap';
import { HYGIENE_FACTOR_META } from '../utils/hygiene';

interface HygieneBreakdownProps {
  factors: HygieneFactors;
  compact?: boolean;
}

export function HygieneBreakdown({ factors, compact = false }: HygieneBreakdownProps) {
  return (
    <div className={compact ? 'space-y-3' : 'space-y-4'}>
      {HYGIENE_FACTOR_META.map((meta) => {
        const value = factors[meta.key] || 0;
        const pct = Math.min(100, Math.max(0, (value / 5) * 100));
        const barColor =
          value >= 4.5
            ? 'bg-[#15803D]'
            : value >= 3.5
            ? 'bg-[#D97706]'
            : 'bg-[#B91C1C]';

        return (
          <div key={meta.key} className="space-y-1.5">
            <div className="flex items-baseline justify-between gap-4">
              <div className="min-w-0">
                <span className="text-sm font-semibold text-[#1C1917]">{meta.label}</span>
                <span className="ml-2 text-xs font-mono text-[#78716C] tabular-nums">
                  ({meta.weightPercent}% weight)
                </span>
              </div>
              <span className="text-sm font-mono font-semibold text-[#1C1917] tabular-nums shrink-0">
                {value > 0 ? value.toFixed(1) : '—'} / 5.0
              </span>
            </div>

            <div className="h-2 w-full rounded-full bg-[#E7E5E4] overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${barColor}`}
                style={{ width: `${pct}%` }}
                role="progressbar"
                aria-valuenow={value}
                aria-valuemin={0}
                aria-valuemax={5}
                aria-label={`${meta.label}: ${value} out of 5`}
              />
            </div>

            {!compact && (
              <p className="text-xs text-[#57534E] leading-relaxed">{meta.description}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}
