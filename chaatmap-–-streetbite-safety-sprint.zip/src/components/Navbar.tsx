import { FormEvent, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, Search, X } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

const NAV_ITEMS = [
  { to: '/', label: 'Home' },
  { to: '/explore', label: 'Explore' },
  { to: '/map', label: 'Map' },
  { to: '/trails', label: 'Food Trails' },
  { to: '/vendor-of-the-month', label: 'Top Vendor' },
];

export function Navbar() {
  const [searchTerm, setSearchTerm] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  function handleSearch(e: FormEvent) {
    e.preventDefault();
    const trimmed = searchTerm.trim();
    setMobileOpen(false);
    if (trimmed) {
      navigate(`/explore?search=${encodeURIComponent(trimmed)}`);
    } else {
      navigate('/explore');
    }
  }

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F6]/95 backdrop-blur-sm border-b border-[#1C1917]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark */}
        <Link
          to="/"
          className="focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#B91C1C] rounded-md"
          aria-label="ChaatMap Home"
        >
          <BrandLogo />
        </Link>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Primary Navigation">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `text-sm font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors duration-150 ${
                  isActive
                    ? 'text-[#B91C1C] border-[#B91C1C]'
                    : 'text-[#57534E] border-transparent hover:text-[#1C1917] hover:border-[#1C1917]/25'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Zone 3: Search action + mobile trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <form onSubmit={handleSearch} className="hidden lg:flex items-center relative">
            <Search className="w-4 h-4 text-[#57534E] absolute left-3 pointer-events-none" />
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search dish or stall..."
              aria-label="Search stalls or dishes"
              className="w-56 pl-9 pr-3 py-1.5 text-sm bg-white border border-[#1C1917]/15 rounded-lg text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#B91C1C]"
            />
          </form>

          <Link
            to="/explore"
            className="hidden sm:inline-flex lg:hidden items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors whitespace-nowrap shrink-0"
          >
            <Search className="w-4 h-4" />
            <span>Find Stalls</span>
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg text-[#1C1917] hover:bg-[#1C1917]/5 focus-visible:outline-2 focus-visible:outline-[#B91C1C]"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-[#1C1917]/10 bg-[#FAF9F6] px-4 py-4 space-y-4">
          <form onSubmit={handleSearch} className="relative">
            <Search className="w-4 h-4 text-[#57534E] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Pani Puri, Sindhi Colony..."
              className="w-full pl-9 pr-4 py-2.5 text-sm bg-white border border-[#1C1917]/15 rounded-lg text-[#1C1917]"
            />
          </form>
          <nav className="flex flex-col space-y-1" aria-label="Mobile Navigation">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `px-3 py-2.5 rounded-lg text-sm font-medium ${
                    isActive
                      ? 'bg-[#B91C1C]/10 text-[#B91C1C]'
                      : 'text-[#1C1917] hover:bg-[#1C1917]/5'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/review"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-lg text-sm font-medium text-[#1C1917] hover:bg-[#1C1917]/5"
            >
              Submit Hygiene Review
            </NavLink>
            <NavLink
              to="/about"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-lg text-sm font-medium text-[#1C1917] hover:bg-[#1C1917]/5"
            >
              About ChaatMap
            </NavLink>
          </nav>
        </div>
      )}
    </header>
  );
}
