import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import L from 'leaflet';
import {
  MapContainer,
  Marker,
  Polyline,
  Popup,
  TileLayer,
  ZoomControl,
  useMap,
  useMapEvents,
} from 'react-leaflet';
import { Vendor } from '../types/chaatmap';
import { formatScore } from '../utils/hygiene';
import { FssaiBadge } from './FssaiBadge';
import { AvailabilityTag } from './AvailabilityTag';

interface InteractiveVendorMapProps {
  vendors: Vendor[];
  selectedVendorId?: number | null;
  onSelectVendor?: (vendor: Vendor) => void;
  heightClass?: string;
  showTrailRoute?: boolean;
  showSequenceNumbers?: boolean;
  enableClustering?: boolean;
}

const HYDERABAD_CENTER: [number, number] = [17.4239, 78.4485];

function createVendorIcon(
  verified: boolean,
  isSelected: boolean,
  sequenceNumber?: number
): L.DivIcon {
  const fill = verified ? '#15803D' : '#B91C1C';
  const ring = isSelected ? '#F59E0B' : '#FFFFFF';
  const scale = isSelected ? 1.18 : 1;

  if (sequenceNumber !== undefined) {
    return L.divIcon({
      className: 'chaatmap-marker-icon',
      iconSize: [34, 42],
      iconAnchor: [17, 42],
      popupAnchor: [0, -38],
      html: `
        <div style="transform: scale(${scale}); transform-origin: bottom center; display:flex; align-items:center; justify-content:center; flex-direction:column;">
          <div style="width:30px;height:30px;border-radius:9999px;background:${fill};border:2.5px solid ${ring};color:#fff;font-family:'JetBrains Mono',monospace;font-weight:700;font-size:13px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 10px rgba(0,0,0,0.28);">
            ${sequenceNumber}
          </div>
          <div style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:8px solid ${fill};margin-top:-1px;"></div>
        </div>
      `,
    });
  }

  return L.divIcon({
    className: 'chaatmap-marker-icon',
    iconSize: [36, 44],
    iconAnchor: [18, 44],
    popupAnchor: [0, -40],
    html: `
      <div style="transform: scale(${scale}); transform-origin: bottom center; filter: drop-shadow(0 4px 8px rgba(28,25,23,0.28));">
        <svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M18 2C9.716 2 3 8.716 3 17C3 27.6 16.05 40.2 17.15 41.24C17.63 41.7 18.37 41.7 18.85 41.24C19.95 40.2 33 27.6 33 17C33 8.716 26.284 2 18 2Z" fill="${fill}" stroke="${ring}" stroke-width="2.2"/>
          <rect x="11" y="11" width="14" height="2.6" rx="1" fill="#FAF9F6"/>
          <rect x="12" y="14.8" width="12" height="5.5" rx="1" fill="#FAF9F6"/>
          <circle cx="14.2" cy="22.4" r="1.5" fill="#FDE68A"/>
          <circle cx="21.8" cy="22.4" r="1.5" fill="#FDE68A"/>
        </svg>
      </div>
    `,
  });
}

function createClusterIcon(count: number, locality: string): L.DivIcon {
  return L.divIcon({
    className: 'chaatmap-marker-icon',
    iconSize: [44, 44],
    iconAnchor: [22, 22],
    html: `
      <div title="${locality}: ${count} stalls" style="width:42px;height:42px;border-radius:9999px;background:#1C1917;color:#FAF9F6;border:2.5px solid #FAF9F6;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;font-family:'JetBrains Mono',monospace;font-weight:700;font-size:13px;">
        ${count}
      </div>
    `,
  });
}

function MapViewportController({
  vendors,
  selectedVendorId,
  showTrailRoute,
  onZoomChange,
}: {
  vendors: Vendor[];
  selectedVendorId?: number | null;
  showTrailRoute?: boolean;
  onZoomChange: (z: number) => void;
}) {
  const map = useMap();

  useMapEvents({
    zoomend: () => {
      onZoomChange(map.getZoom());
    },
  });

  useEffect(() => {
    if (selectedVendorId) {
      const target = vendors.find((v) => v.id === selectedVendorId);
      if (target) {
        map.flyTo([target.latitude, target.longitude], 15, { duration: 0.65 });
        return;
      }
    }

    if (showTrailRoute && vendors.length >= 2) {
      const bounds = L.latLngBounds(vendors.map((v) => [v.latitude, v.longitude] as [number, number]));
      map.fitBounds(bounds, { padding: [48, 48], maxZoom: 15 });
    }
  }, [selectedVendorId, showTrailRoute, vendors, map]);

  return null;
}

function ClusterMarkerItem({
  locality,
  items,
  lat,
  lng,
}: {
  locality: string;
  items: Vendor[];
  lat: number;
  lng: number;
}) {
  const map = useMap();
  return (
    <Marker
      position={[lat, lng]}
      icon={createClusterIcon(items.length, locality)}
      eventHandlers={{
        click: () => {
          map.flyTo([lat, lng], 15, { duration: 0.5 });
        },
      }}
    >
      <Popup>
        <div className="p-3 space-y-1">
          <p className="font-display font-semibold text-sm text-[#1C1917]">{locality}</p>
          <p className="text-xs text-[#57534E]">
            {items.length} street food stalls here. Click zoom or pin to inspect individual stalls.
          </p>
        </div>
      </Popup>
    </Marker>
  );
}

export function InteractiveVendorMap({
  vendors,
  selectedVendorId = null,
  onSelectVendor,
  heightClass = 'h-[540px]',
  showTrailRoute = false,
  showSequenceNumbers = false,
  enableClustering = false,
}: InteractiveVendorMapProps) {
  const [zoomLevel, setZoomLevel] = useState(12);

  const initialCenter = useMemo<[number, number]>(() => {
    if (selectedVendorId) {
      const match = vendors.find((v) => v.id === selectedVendorId);
      if (match) return [match.latitude, match.longitude];
    }
    if (vendors.length > 0 && showTrailRoute) {
      return [vendors[0].latitude, vendors[0].longitude];
    }
    return HYDERABAD_CENTER;
  }, [selectedVendorId, vendors, showTrailRoute]);

  const clusters = useMemo(() => {
    if (!enableClustering || zoomLevel > 12 || showTrailRoute) {
      return null;
    }
    const byLocality = new Map<string, Vendor[]>();
    for (const v of vendors) {
      const arr = byLocality.get(v.locality) || [];
      arr.push(v);
      byLocality.set(v.locality, arr);
    }
    return Array.from(byLocality.entries()).map(([locality, items]) => {
      const avgLat = items.reduce((s, x) => s + x.latitude, 0) / items.length;
      const avgLng = items.reduce((s, x) => s + x.longitude, 0) / items.length;
      return { locality, items, lat: avgLat, lng: avgLng };
    });
  }, [enableClustering, zoomLevel, showTrailRoute, vendors]);

  const routePositions = useMemo<[number, number][]>(() => {
    if (!showTrailRoute || vendors.length < 2) return [];
    return vendors.map((v) => [v.latitude, v.longitude]);
  }, [showTrailRoute, vendors]);

  return (
    <div className={`relative w-full rounded-xl overflow-hidden border border-[#1C1917]/15 bg-[#EFECE6] ${heightClass}`}>
      <MapContainer
        center={initialCenter}
        zoom={selectedVendorId ? 15 : 12}
        zoomControl={false}
        scrollWheelZoom={true}
        className="w-full h-full"
      >
        <ZoomControl position="bottomright" />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapViewportController
          vendors={vendors}
          selectedVendorId={selectedVendorId}
          showTrailRoute={showTrailRoute}
          onZoomChange={setZoomLevel}
        />

        {routePositions.length >= 2 && (
          <Polyline
            positions={routePositions}
            pathOptions={{
              color: '#B91C1C',
              weight: 3.5,
              opacity: 0.85,
              dashArray: '8, 8',
            }}
          />
        )}

        {clusters
          ? clusters.map((cluster) =>
              cluster.items.length === 1 ? (
                <VendorMarkerItem
                  key={cluster.items[0].id}
                  vendor={cluster.items[0]}
                  isSelected={cluster.items[0].id === selectedVendorId}
                  onSelect={onSelectVendor}
                />
              ) : (
                <ClusterMarkerItem
                  key={cluster.locality}
                  locality={cluster.locality}
                  items={cluster.items}
                  lat={cluster.lat}
                  lng={cluster.lng}
                />
              )
            )
          : vendors.map((vendor, index) => (
              <VendorMarkerItem
                key={vendor.id}
                vendor={vendor}
                isSelected={vendor.id === selectedVendorId}
                sequenceNumber={showSequenceNumbers ? index + 1 : undefined}
                onSelect={onSelectVendor}
              />
            ))}
      </MapContainer>

      {/* Map legend overlay */}
      <div className="absolute top-3 left-3 z-[400] bg-white/95 backdrop-blur-sm border border-[#1C1917]/10 rounded-lg px-3 py-2 text-xs text-[#1C1917] shadow-sm flex flex-wrap items-center gap-4">
        <span className="inline-flex items-center gap-1.5 font-medium">
          <span className="w-3 h-3 rounded-sm bg-[#15803D] inline-block" aria-hidden="true" />
          FSSAI Verified
        </span>
        <span className="inline-flex items-center gap-1.5 font-medium">
          <span className="w-3 h-3 rounded-sm bg-[#B91C1C] inline-block" aria-hidden="true" />
          Not Verified
        </span>
      </div>
    </div>
  );
}

function VendorMarkerItem({
  vendor,
  isSelected,
  sequenceNumber,
  onSelect,
}: {
  vendor: Vendor;
  isSelected: boolean;
  sequenceNumber?: number;
  onSelect?: (v: Vendor) => void;
}) {
  return (
    <Marker
      position={[vendor.latitude, vendor.longitude]}
      icon={createVendorIcon(vendor.fssai_verified, isSelected, sequenceNumber)}
      eventHandlers={{
        click: () => {
          onSelect?.(vendor);
        },
      }}
    >
      <Popup>
        <div className="p-3.5 space-y-2.5 w-64">
          <div className="space-y-1">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#57534E]">
                {vendor.locality} · {vendor.cuisine}
              </span>
              <span className="font-mono text-xs font-bold text-[#1C1917] tabular-nums">
                {formatScore(vendor.hygiene_score)}/5
              </span>
            </div>
            <h4 className="font-display text-sm font-bold text-[#1C1917] leading-snug">
              {vendor.name}
            </h4>
            <p className="text-xs text-[#57534E]">
              Signature: <span className="text-[#1C1917] font-medium">{vendor.signature_dish}</span>
            </p>
          </div>

          <div className="flex items-center justify-between text-xs pt-1 border-t border-[#1C1917]/10">
            <span className="font-mono font-semibold text-[#1C1917] tabular-nums">
              ₹{vendor.price_min}–₹{vendor.price_max}
            </span>
            <AvailabilityTag
              status={vendor.availability_status}
              updatedAt={vendor.availability_updated_at}
              showTimestamp={false}
            />
          </div>

          <div className="flex items-center justify-between gap-2 pt-1">
            <FssaiBadge verified={vendor.fssai_verified} />
            <Link
              to={`/vendors/${vendor.id}`}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-[#B91C1C] rounded-md hover:bg-[#991B1B] transition-colors whitespace-nowrap"
            >
              View Details
            </Link>
          </div>
        </div>
      </Popup>
    </Marker>
  );
}
