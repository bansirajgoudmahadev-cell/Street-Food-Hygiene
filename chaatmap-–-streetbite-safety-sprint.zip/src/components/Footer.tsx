import { Link } from 'react-router-dom';
import { BrandLogo } from './BrandLogo';

export function Footer() {
  return (
    <footer className="border-t border-[#1C1917]/10 bg-[#F3F1EC] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-[#1C1917]/10">
          <div className="md:col-span-5 space-y-3">
            <Link to="/" className="inline-block">
              <BrandLogo />
            </Link>
            <p className="text-sm font-medium text-[#1C1917]">
              Discover Street Food. Trust the Hygiene.
            </p>
            <p className="text-sm text-[#57534E] leading-relaxed max-w-md">
              A community-driven street food discovery and four-factor sanitation evaluation directory for Hyderabad localities.
            </p>
          </div>

          <div className="md:col-span-3 space-y-2.5">
            <h3 className="text-sm font-semibold text-[#1C1917]">Explore</h3>
            <ul className="space-y-2 text-sm text-[#57534E]">
              <li><Link to="/explore" className="hover:text-[#B91C1C] transition-colors">Vendor Directory</Link></li>
              <li><Link to="/map" className="hover:text-[#B91C1C] transition-colors">Interactive Map</Link></li>
              <li><Link to="/trails" className="hover:text-[#B91C1C] transition-colors">Hygiene Food Trails</Link></li>
              <li><Link to="/vendor-of-the-month" className="hover:text-[#B91C1C] transition-colors">Vendor of the Month</Link></li>
            </ul>
          </div>

          <div className="md:col-span-4 space-y-2.5">
            <h3 className="text-sm font-semibold text-[#1C1917]">Community & Transparency</h3>
            <ul className="space-y-2 text-sm text-[#57534E]">
              <li><Link to="/review" className="hover:text-[#B91C1C] transition-colors">Submit a Hygiene Review</Link></li>
              <li><Link to="/about" className="hover:text-[#B91C1C] transition-colors">Hygiene Scoring Methodology</Link></li>
              <li><Link to="/about#fssai" className="hover:text-[#B91C1C] transition-colors">FSSAI Verification Notice</Link></li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-[#57534E]">
          <p>
            ChaatMap – StreetBite Safety Sprint · Sample Hyderabad dataset for civic food-safety demonstration.
          </p>
          <p>
            FSSAI indicators in seed data are illustrative and do not connect to an official government registry.
          </p>
        </div>
      </div>
    </footer>
  );
}
