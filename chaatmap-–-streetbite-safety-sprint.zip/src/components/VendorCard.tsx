import { Link } from 'react-router-dom';
import { Clock, MapPin, Star } from 'lucide-react';
import { Vendor } from '../types/chaatmap';
import { formatScore, formatTime12h } from '../utils/hygiene';
import { FallbackImage } from './FallbackImage';
import { FssaiBadge } from './FssaiBadge';
import { AvailabilityTag } from './AvailabilityTag';

interface VendorCardProps {
  vendor: Vendor;
}

export function VendorCard({ vendor }: VendorCardProps) {
  const dishSummary = vendor.dishes
    .slice(0, 2)
    .map((d) => d.dish_name)
    .join(', ');

  return (
    <article className="group bg-white border border-[#1C1917]/10 rounded-xl overflow-hidden flex flex-col transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <Link to={`/vendors/${vendor.id}`} className="block relative aspect-[4/3] overflow-hidden bg-[#EFECE6]">
        <FallbackImage
          src={vendor.image}
          alt={`${vendor.name} — ${vendor.cuisine}`}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </Link>

      <div className="p-5 flex-1 flex flex-col justify-between gap-4">
        <div className="space-y-2.5">
          {/* Unboxed metadata line */}
          <div className="flex items-center justify-between gap-2 text-xs text-[#57534E]">
            <span className="truncate font-medium">
              {vendor.locality} <span aria-hidden="true">·</span> {vendor.cuisine}
            </span>
            <FssaiBadge verified={vendor.fssai_verified} />
          </div>

          <h3 className="font-display text-lg font-semibold text-[#1C1917] leading-snug">
            <Link
              to={`/vendors/${vendor.id}`}
              className="hover:text-[#B91C1C] transition-colors focus-visible:outline-2 focus-visible:outline-[#B91C1C]"
            >
              {vendor.name}
            </Link>
          </h3>

          <p className="text-xs text-[#57534E] flex items-start gap-1.5 leading-relaxed">
            <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#78716C]" aria-hidden="true" />
            <span>{vendor.landmark}</span>
          </p>

          <p className="text-sm text-[#44403C] line-clamp-2 leading-relaxed">
            <span className="font-medium text-[#1C1917]">Dishes:</span> {dishSummary || vendor.signature_dish}
          </p>
        </div>

        <div className="space-y-3 pt-3 border-t border-[#1C1917]/8">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <Star className="w-4 h-4 fill-[#D97706] text-[#D97706] shrink-0" aria-hidden="true" />
              <span className="font-mono text-sm font-semibold text-[#1C1917] tabular-nums">
                {formatScore(vendor.hygiene_score)}/5
              </span>
              <span className="text-xs text-[#78716C] tabular-nums">
                ({vendor.review_count} {vendor.review_count === 1 ? 'review' : 'reviews'})
              </span>
            </div>

            <span className="font-mono text-sm font-semibold text-[#1C1917] tabular-nums">
              ₹{vendor.price_min}–₹{vendor.price_max}
            </span>
          </div>

          <div className="flex items-center justify-between gap-2 text-xs text-[#57534E]">
            <AvailabilityTag
              status={vendor.availability_status}
              updatedAt={vendor.availability_updated_at}
              showTimestamp={false}
            />
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Clock className="w-3.5 h-3.5 text-[#78716C]" aria-hidden="true" />
              <span>
                {formatTime12h(vendor.opening_time)} – {formatTime12h(vendor.closing_time)}
              </span>
            </span>
          </div>

          <div className="pt-1 flex items-center gap-2">
            <Link
              to={`/vendors/${vendor.id}`}
              className="flex-1 text-center px-3 py-2 text-xs font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors whitespace-nowrap"
            >
              View Details
            </Link>
            <Link
              to={`/map?vendorId=${vendor.id}`}
              className="px-3 py-2 text-xs font-semibold text-[#1C1917] bg-[#F3F1EC] rounded-lg hover:bg-[#E7E5E4] transition-colors whitespace-nowrap"
            >
              View on Map
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
}
