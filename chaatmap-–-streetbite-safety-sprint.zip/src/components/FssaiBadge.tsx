import { ShieldAlert, ShieldCheck } from 'lucide-react';

interface FssaiBadgeProps {
  verified: boolean;
  showTooltipNote?: boolean;
}

export function FssaiBadge({ verified, showTooltipNote = false }: FssaiBadgeProps) {
  if (verified) {
    return (
      <span
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#15803D] whitespace-nowrap shrink-0"
        title={
          showTooltipNote
            ? 'Illustrative demo verification record in ChaatMap database (not live government API).'
            : undefined
        }
      >
        <ShieldCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
        <span>FSSAI Verified</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#78716C] whitespace-nowrap shrink-0">
      <ShieldAlert className="w-4 h-4 shrink-0" aria-hidden="true" />
      <span>Not Verified</span>
    </span>
  );
}
