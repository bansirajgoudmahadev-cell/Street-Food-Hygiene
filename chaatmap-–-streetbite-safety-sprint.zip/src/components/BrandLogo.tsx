export function BrandLogo({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${className}`}>
      <svg
        width="28"
        height="28"
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        {/* Location pin silhouette */}
        <path
          d="M16 2C9.925 2 5 6.925 5 13C5 20.8 14.55 29.15 15.32 29.8C15.71 30.13 16.29 30.13 16.68 29.8C17.45 29.15 27 20.8 27 13C27 6.925 22.075 2 16 2Z"
          fill="#B91C1C"
        />
        {/* Food cart canopy + counter inside pin */}
        <rect x="9.5" y="9" width="13" height="2.4" rx="1" fill="#FAF9F6" />
        <rect x="10.5" y="12.5" width="11" height="5" rx="1" fill="#FAF9F6" />
        <circle cx="12.5" cy="19.3" r="1.4" fill="#FDE68A" />
        <circle cx="19.5" cy="19.3" r="1.4" fill="#FDE68A" />
      </svg>
      <span className="font-display text-xl font-bold tracking-tight text-[#1C1917]">
        ChaatMap
      </span>
    </span>
  );
}
