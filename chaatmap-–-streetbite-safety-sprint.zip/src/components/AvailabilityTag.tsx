import { CheckCircle2, Clock, HelpCircle, XCircle } from 'lucide-react';
import { AvailabilityStatus } from '../types/chaatmap';
import { formatRelativeTime, isAvailabilityStale } from '../utils/hygiene';

interface AvailabilityTagProps {
  status: AvailabilityStatus;
  updatedAt: string;
  showTimestamp?: boolean;
}

export function AvailabilityTag({ status, updatedAt, showTimestamp = true }: AvailabilityTagProps) {
  const stale = isAvailabilityStale(updatedAt);
  const relative = formatRelativeTime(updatedAt);

  const config =
    status === 'Open'
      ? {
          icon: CheckCircle2,
          color: 'text-[#15803D]',
          label: 'Open',
        }
      : status === 'Closed'
      ? {
          icon: XCircle,
          color: 'text-[#B91C1C]',
          label: 'Closed',
        }
      : {
          icon: HelpCircle,
          color: 'text-[#78716C]',
          label: 'Unknown',
        };

  const Icon = config.icon;

  return (
    <span className="inline-flex items-center gap-1.5 text-xs whitespace-nowrap">
      <Icon className={`w-3.5 h-3.5 shrink-0 ${config.color}`} aria-hidden="true" />
      <span className={`font-semibold ${config.color}`}>{config.label}</span>
      {showTimestamp && (
        <span className="text-[#78716C] inline-flex items-center gap-1">
          <span aria-hidden="true">·</span>
          <Clock className="w-3 h-3" aria-hidden="true" />
          <span>{stale ? `Last checked ${relative} (unconfirmed)` : `Updated ${relative}`}</span>
        </span>
      )}
    </span>
  );
}
