import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Camera,
  Clock,
  MapPin,
  Navigation,
  ShieldCheck,
  Star,
  Upload,
} from 'lucide-react';
import {
  fetchVendorDetails,
  updateVendorAvailability,
  uploadVendorPhoto,
} from '../api/client';
import {
  AvailabilityStatus,
  HygieneReview,
  Vendor,
  VendorPhoto,
} from '../types/chaatmap';
import { formatRelativeTime, formatScore, formatTime12h } from '../utils/hygiene';
import { FallbackImage } from '../components/FallbackImage';
import { FssaiBadge } from '../components/FssaiBadge';
import { AvailabilityTag } from '../components/AvailabilityTag';
import { HygieneBreakdown } from '../components/HygieneBreakdown';

export function VendorDetailsPage() {
  const { id } = useParams();
  const vendorId = Number(id);

  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [reviews, setReviews] = useState<HygieneReview[]>([]);
  const [photos, setPhotos] = useState<VendorPhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Real-time availability form state
  const [statusUpdating, setStatusUpdating] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState('');
  const [pushcartLandmark, setPushcartLandmark] = useState('');

  // Community photo upload state
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoCaption, setPhotoCaption] = useState('');
  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoFeedback, setPhotoFeedback] = useState('');

  const loadVendor = useCallback(async () => {
    if (!Number.isInteger(vendorId) || vendorId <= 0) {
      setError('Invalid vendor identifier.');
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      setError('');
      const data = await fetchVendorDetails(vendorId);
      setVendor(data.vendor);
      setReviews(data.reviews);
      setPhotos(data.photos);
      setPushcartLandmark(data.vendor.landmark);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load vendor details.');
    } finally {
      setLoading(false);
    }
  }, [vendorId]);

  useEffect(() => {
    loadVendor();
  }, [loadVendor]);

  async function handleAvailabilityUpdate(newStatus: AvailabilityStatus) {
    if (!vendor) return;
    try {
      setStatusUpdating(true);
      setStatusFeedback('');
      const res = await updateVendorAvailability(vendor.id, {
        availability_status: newStatus,
        landmark: vendor.is_pushcart ? pushcartLandmark : undefined,
      });
      setVendor(res.vendor);
      setStatusFeedback(`Availability updated to "${newStatus}" just now.`);
    } catch (err) {
      setStatusFeedback(err instanceof Error ? err.message : 'Update failed.');
    } finally {
      setStatusUpdating(false);
    }
  }

  async function handlePhotoUpload(e: FormEvent) {
    e.preventDefault();
    if (!vendor || !photoFile) {
      setPhotoFeedback('Please select a JPG, PNG, or WebP image file first.');
      return;
    }
    try {
      setPhotoUploading(true);
      setPhotoFeedback('');
      const res = await uploadVendorPhoto(vendor.id, photoFile, photoCaption);
      setPhotos((prev) => [res.photo, ...prev]);
      setPhotoFile(null);
      setPhotoCaption('');
      setPhotoFeedback('Photo added to this vendor’s community gallery.');
    } catch (err) {
      setPhotoFeedback(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setPhotoUploading(false);
    }
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
        <div className="h-72 rounded-xl bg-[#EFECE6] animate-pulse" />
        <div className="h-96 rounded-xl bg-[#EFECE6] animate-pulse" />
      </div>
    );
  }

  if (error || !vendor) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#1C1917]">
          {error || 'Vendor not found'}
        </h1>
        <Link
          to="/explore"
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Vendor Directory</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      <div>
        <Link
          to="/explore"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-[#57534E] hover:text-[#B91C1C] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Vendor Directory</span>
        </Link>
      </div>

      {/* Top Vendor Overview Grid */}
      <section className="bg-white border border-[#1C1917]/10 rounded-xl overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-5 relative min-h-[280px] bg-[#EFECE6]">
            <FallbackImage
              src={vendor.image}
              alt={vendor.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-6">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs font-semibold text-[#57534E]">
                  {vendor.locality} · {vendor.cuisine}
                  {vendor.is_pushcart ? ' · Mobile Pushcart' : ' · Fixed Counter'}
                </span>
                <FssaiBadge verified={vendor.fssai_verified} showTooltipNote />
              </div>

              <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#1C1917]">
                {vendor.name}
              </h1>

              <p className="text-sm text-[#44403C] leading-relaxed">{vendor.description}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-sm text-[#44403C]">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#1C1917]">{vendor.landmark}</p>
                    <p className="text-xs text-[#57534E]">{vendor.address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#1C1917] tabular-nums">
                      {formatTime12h(vendor.opening_time)} – {formatTime12h(vendor.closing_time)}
                    </p>
                    <p className="text-xs font-mono text-[#57534E] tabular-nums">
                      GPS: {vendor.latitude.toFixed(4)}° N, {vendor.longitude.toFixed(4)}° E
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <AvailabilityTag
                  status={vendor.availability_status}
                  updatedAt={vendor.availability_updated_at}
                />
              </div>
            </div>

            {/* Hygiene Score Highlight + Primary CTAs */}
            <div className="pt-5 border-t border-[#1C1917]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-[#FAF9F6] border border-[#1C1917]/10 rounded-xl px-4 py-2.5 text-center">
                  <div className="flex items-center justify-center gap-1.5">
                    <Star className="w-5 h-5 fill-[#D97706] text-[#D97706]" />
                    <span className="font-mono text-2xl font-bold text-[#1C1917] tabular-nums">
                      {formatScore(vendor.hygiene_score)}
                    </span>
                    <span className="font-mono text-sm text-[#78716C]">/5</span>
                  </div>
                  <p className="text-[11px] font-medium text-[#57534E] mt-0.5">
                    Hygiene Trust Score
                  </p>
                </div>

                <div className="text-sm">
                  <p className="font-semibold text-[#1C1917] tabular-nums">
                    {vendor.review_count} {vendor.review_count === 1 ? 'Audit Review' : 'Audit Reviews'}
                  </p>
                  <p className="font-mono text-xs text-[#57534E] tabular-nums">
                    Typical Spend: ₹{vendor.price_min}–₹{vendor.price_max}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <Link
                  to={`/review/${vendor.id}`}
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors whitespace-nowrap"
                >
                  Submit Hygiene Review
                </Link>
                <Link
                  to={`/map?vendorId=${vendor.id}`}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-[#1C1917] bg-[#F3F1EC] rounded-lg hover:bg-[#E7E5E4] transition-colors whitespace-nowrap"
                >
                  <Navigation className="w-4 h-4 text-[#B91C1C]" />
                  <span>View on Map</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Details Grid: Four-Factor Breakdown + Signature Dishes + Live Status Reporting */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-8">
          {/* Four-Factor Hygiene Breakdown */}
          <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-5">
            <div className="flex flex-wrap items-baseline justify-between gap-2 pb-3 border-b border-[#1C1917]/8">
              <div>
                <h2 className="font-display text-xl font-bold text-[#1C1917]">
                  Four-Factor Hygiene Breakdown
                </h2>
                <p className="text-xs text-[#57534E] mt-0.5">
                  Weighted formula: 40% Water + 25% Covered Food + 20% Gloves + 15% Surroundings
                </p>
              </div>
              <span className="font-mono text-sm font-bold text-[#15803D] tabular-nums">
                Score: {vendor.hygiene_score.toFixed(2)} / 5.00
              </span>
            </div>

            <HygieneBreakdown factors={vendor.hygiene_factors} />

            {/* FSSAI Transparency Note */}
            <div className="pt-4 border-t border-[#1C1917]/8 flex items-start gap-2.5 text-xs text-[#57534E]">
              <ShieldCheck className="w-4 h-4 text-[#15803D] shrink-0 mt-0.5" />
              <p>
                {vendor.fssai_verified
                  ? 'This stall carries an illustrative FSSAI Verified indicator in ChaatMap’s sample seed dataset. Demonstration records do not connect directly to the official FSSAI FoSCoS government portal.'
                  : 'No FSSAI registration record is attached to this sample vendor profile. Diners should rely on the four-factor hygiene audit above.'}
              </p>
            </div>
          </section>

          {/* Customer Observations */}
          <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-[#1C1917]">
                Community Hygiene Observations ({reviews.length})
              </h2>
              <Link
                to={`/review/${vendor.id}`}
                className="text-xs font-semibold text-[#B91C1C] hover:underline"
              >
                + Add Review
              </Link>
            </div>

            {reviews.length === 0 ? (
              <p className="text-sm text-[#57534E] py-4">
                No hygiene audits submitted yet. Be the first to rate this stall’s sanitation practices.
              </p>
            ) : (
              <div className="divide-y divide-[#1C1917]/8">
                {reviews.map((rev) => (
                  <article key={rev.id} className="py-4 first:pt-0 last:pb-0 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold text-[#1C1917]">{rev.reviewer_name}</p>
                        <p className="text-xs text-[#78716C]">{formatRelativeTime(rev.created_at)}</p>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-[#44403C] tabular-nums">
                        <span>Water: {rev.water_cleanliness}/5</span>
                        <span>·</span>
                        <span>Covered: {rev.covered_food}/5</span>
                        <span>·</span>
                        <span>Gloves: {rev.glove_usage}/5</span>
                        <span>·</span>
                        <span>Area: {rev.surroundings}/5</span>
                      </div>
                    </div>
                    {rev.observation && (
                      <p className="text-sm text-[#44403C] leading-relaxed">{rev.observation}</p>
                    )}
                    {rev.photo && (
                      <div className="w-48 aspect-[4/3] rounded-lg overflow-hidden border border-[#1C1917]/10">
                        <FallbackImage
                          src={rev.photo}
                          alt={`Review photo by ${rev.reviewer_name}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </article>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Right Column: Signature Dishes, Live Availability Reporter, Photo Gallery */}
        <div className="lg:col-span-5 space-y-8">
          {/* Signature Dishes */}
          <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-xl font-bold text-[#1C1917]">
              Signature Delicacies & Prices
            </h2>
            <div className="divide-y divide-[#1C1917]/8">
              {vendor.dishes.map((dish) => (
                <div key={dish.id} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-[#1C1917]">{dish.dish_name}</p>
                    <p className="text-xs text-[#57534E] mt-0.5 leading-relaxed">{dish.description}</p>
                  </div>
                  <span className="font-mono text-sm font-bold text-[#1C1917] tabular-nums shrink-0">
                    ₹{dish.price}
                  </span>
                </div>
              ))}
            </div>
          </section>

          {/* Real-Time Open/Closed Crowd-Sourced Updater */}
          <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-lg font-bold text-[#1C1917]">
                Report Live Stall Availability
              </h2>
              <p className="text-xs text-[#57534E] mt-1">
                Are you at this stall right now? Update whether the vendor is currently operating.
              </p>
            </div>

            {vendor.is_pushcart && (
              <div className="space-y-1.5">
                <label htmlFor="pushcart-landmark" className="block text-xs font-semibold text-[#57534E]">
                  Pushcart Usual Landmark (updatable for mobile carts)
                </label>
                <input
                  id="pushcart-landmark"
                  type="text"
                  value={pushcartLandmark}
                  onChange={(e) => setPushcartLandmark(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917]"
                />
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              {(['Open', 'Closed', 'Unknown'] as AvailabilityStatus[]).map((st) => {
                const isCurrent = vendor.availability_status === st;
                return (
                  <button
                    key={st}
                    type="button"
                    disabled={statusUpdating}
                    onClick={() => handleAvailabilityUpdate(st)}
                    className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      isCurrent
                        ? 'bg-[#1C1917] text-white border-[#1C1917]'
                        : 'bg-[#FAF9F6] text-[#1C1917] border-[#1C1917]/15 hover:bg-[#EFECE6]'
                    }`}
                  >
                    Mark {st}
                  </button>
                );
              })}
            </div>

            {statusFeedback && (
              <p className="text-xs font-medium text-[#15803D]">{statusFeedback}</p>
            )}
          </section>

          {/* Community Photographs & Direct Upload */}
          <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-[#B91C1C]" />
              <h2 className="font-display text-lg font-bold text-[#1C1917]">
                Community Stall Photos ({photos.length})
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {photos.map((p) => (
                <figure key={p.id} className="space-y-1">
                  <div className="aspect-[4/3] rounded-lg overflow-hidden border border-[#1C1917]/10 bg-[#EFECE6]">
                    <FallbackImage
                      src={p.photo_url}
                      alt={p.caption || vendor.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {p.caption && (
                    <figcaption className="text-[11px] text-[#57534E] truncate">{p.caption}</figcaption>
                  )}
                </figure>
              ))}
            </div>

            <form onSubmit={handlePhotoUpload} className="pt-3 border-t border-[#1C1917]/8 space-y-3">
              <p className="text-xs font-semibold text-[#1C1917]">Upload a Stall Photo</p>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                className="block w-full text-xs text-[#57534E] file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-[#F3F1EC] file:text-[#1C1917] hover:file:bg-[#E7E5E4]"
              />
              <input
                type="text"
                value={photoCaption}
                onChange={(e) => setPhotoCaption(e.target.value)}
                placeholder="Caption (e.g., Covered chutney counter)"
                className="w-full px-3 py-2 text-xs bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg"
              />
              <button
                type="submit"
                disabled={photoUploading || !photoFile}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] disabled:opacity-50 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{photoUploading ? 'Uploading...' : 'Upload Photo'}</span>
              </button>
              {photoFeedback && (
                <p className="text-xs text-[#57534E]">{photoFeedback}</p>
              )}
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}
