import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AlertCircle, CheckCircle2, Star, Upload } from 'lucide-react';
import { fetchVendors, submitHygieneReview } from '../api/client';
import { Vendor } from '../types/chaatmap';
import {
  calculateHygieneTrustScore,
  FactorInput,
  HYGIENE_FACTOR_META,
} from '../utils/hygiene';

const SUBMITTED_TRACKER_KEY = 'chaatmap_recent_reviews_v1';

export function SubmitReviewPage() {
  const { vendorId: paramVendorId } = useParams();

  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedVendorId, setSelectedVendorId] = useState<number>(
    paramVendorId ? Number(paramVendorId) : 0
  );
  const [reviewerName, setReviewerName] = useState('');
  const [ratings, setRatings] = useState<FactorInput>({
    water_cleanliness: 0,
    covered_food: 0,
    glove_usage: 0,
    surroundings: 0,
  });
  const [observation, setObservation] = useState('');
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');

  const [loadingVendors, setLoadingVendors] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successResult, setSuccessResult] = useState<{
    vendorId: number;
    vendorName: string;
    newScore: number;
    reviewCount: number;
  } | null>(null);
  const [alreadyReviewedInBrowser, setAlreadyReviewedInBrowser] = useState(false);

  useEffect(() => {
    let active = true;
    fetchVendors({ sort: 'hygiene' })
      .then((list) => {
        if (!active) return;
        setVendors(list);
        if (paramVendorId && list.some((v) => v.id === Number(paramVendorId))) {
          setSelectedVendorId(Number(paramVendorId));
        } else if (!selectedVendorId && list.length > 0) {
          setSelectedVendorId(list[0].id);
        }
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load vendor list.');
      })
      .finally(() => {
        if (active) setLoadingVendors(false);
      });
    return () => {
      active = false;
    };
  }, [paramVendorId]);

  useEffect(() => {
    if (!selectedVendorId) return;
    try {
      const raw = sessionStorage.getItem(SUBMITTED_TRACKER_KEY);
      const ids: number[] = raw ? JSON.parse(raw) : [];
      setAlreadyReviewedInBrowser(ids.includes(selectedVendorId));
    } catch {
      setAlreadyReviewedInBrowser(false);
    }
  }, [selectedVendorId]);

  useEffect(() => {
    if (!photo) {
      setPhotoPreview('');
      return;
    }
    const url = URL.createObjectURL(photo);
    setPhotoPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);

  const allRated =
    ratings.water_cleanliness > 0 &&
    ratings.covered_food > 0 &&
    ratings.glove_usage > 0 &&
    ratings.surroundings > 0;

  const previewScore = useMemo(() => {
    if (!allRated) return null;
    return calculateHygieneTrustScore(ratings);
  }, [allRated, ratings]);

  const selectedVendor = vendors.find((v) => v.id === selectedVendorId) || null;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setSuccessResult(null);

    if (!selectedVendorId) {
      setError('Please choose a street food vendor.');
      return;
    }
    if (!allRated) {
      setError('Please rate all four hygiene criteria from 1 to 5 stars before submitting.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await submitHygieneReview(selectedVendorId, {
        reviewer_name: reviewerName.trim() || 'Community Diner',
        ...ratings,
        observation: observation.trim(),
        photo,
      });

      try {
        const raw = sessionStorage.getItem(SUBMITTED_TRACKER_KEY);
        const ids: number[] = raw ? JSON.parse(raw) : [];
        if (!ids.includes(selectedVendorId)) {
          sessionStorage.setItem(SUBMITTED_TRACKER_KEY, JSON.stringify([...ids, selectedVendorId]));
        }
        setAlreadyReviewedInBrowser(true);
      } catch {
        // Ignore session storage errors
      }

      setSuccessResult({
        vendorId: res.vendor.id,
        vendorName: res.vendor.name,
        newScore: res.vendor.hygiene_score,
        reviewCount: res.vendor.review_count,
      });

      setRatings({
        water_cleanliness: 0,
        covered_food: 0,
        glove_usage: 0,
        surroundings: 0,
      });
      setObservation('');
      setPhoto(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit review.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1C1917]">
          Submit a Structured Hygiene Review
        </h1>
        <p className="text-sm sm:text-base text-[#57534E]">
          Evaluate four observable sanitation criteria. Your ratings immediately recalculate the vendor’s Hygiene Trust Score.
        </p>
      </div>

      {successResult && (
        <div
          role="status"
          className="bg-[#15803D]/8 border border-[#15803D]/30 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#15803D] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-sm font-semibold text-[#1C1917]">
                Hygiene review saved for {successResult.vendorName}
              </p>
              <p className="text-xs text-[#44403C]">
                Updated Hygiene Trust Score:{' '}
                <strong className="font-mono text-[#15803D] tabular-nums">
                  {successResult.newScore.toFixed(2)} / 5.00
                </strong>{' '}
                across {successResult.reviewCount} reviews.
              </p>
            </div>
          </div>
          <Link
            to={`/vendors/${successResult.vendorId}`}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#15803D] rounded-lg hover:bg-[#166534] transition-colors whitespace-nowrap self-start sm:self-center"
          >
            View Updated Stall
          </Link>
        </div>
      )}

      {error && (
        <div
          role="alert"
          className="bg-[#B91C1C]/8 border border-[#B91C1C]/30 rounded-xl p-4 flex items-start gap-3 text-sm text-[#991B1B]"
        >
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white border border-[#1C1917]/10 rounded-xl p-6 sm:p-8 space-y-8">
        {/* Vendor Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="review-vendor" className="block text-sm font-semibold text-[#1C1917] mb-1.5">
              Select Street Food Vendor
            </label>
            <select
              id="review-vendor"
              value={selectedVendorId}
              disabled={loadingVendors}
              onChange={(e) => setSelectedVendorId(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            >
              {vendors.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.locality})
                </option>
              ))}
            </select>
            {selectedVendor && (
              <p className="text-xs text-[#57534E] mt-1.5">
                Current score:{' '}
                <span className="font-mono font-semibold text-[#1C1917]">
                  {selectedVendor.hygiene_score.toFixed(1)}/5
                </span>{' '}
                · {selectedVendor.landmark}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="reviewer-name" className="block text-sm font-semibold text-[#1C1917] mb-1.5">
              Your Name (optional)
            </label>
            <input
              id="reviewer-name"
              type="text"
              maxLength={60}
              value={reviewerName}
              onChange={(e) => setReviewerName(e.target.value)}
              placeholder="e.g. Rohan K. (defaults to Community Diner)"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            />
          </div>
        </div>

        {alreadyReviewedInBrowser && (
          <div className="p-3.5 rounded-lg bg-[#D97706]/10 border border-[#D97706]/25 text-xs text-[#78350F]">
            Note: You already submitted a review for this stall during this browser session. Because user accounts are not enabled in this demo, duplicate prevention across devices or sessions is not enforced server-side.
          </div>
        )}

        {/* Four-Factor Star Controls */}
        <div className="space-y-5 pt-2 border-t border-[#1C1917]/10">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="font-display text-xl font-bold text-[#1C1917]">
              Four Hygiene Factors (Required)
            </h2>
            <span className="text-xs font-mono text-[#57534E]">
              Formula: 0.40×Water + 0.25×Covered + 0.20×Gloves + 0.15×Area
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {HYGIENE_FACTOR_META.map((factor) => {
              const current = ratings[factor.key];
              return (
                <div
                  key={factor.key}
                  className="bg-[#FAF9F6] border border-[#1C1917]/10 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-semibold text-[#1C1917]">
                        {factor.label}
                      </h3>
                      <p className="text-xs font-mono text-[#B91C1C] tabular-nums">
                        Weight: {factor.weightPercent}%
                      </p>
                    </div>
                    <span className="font-mono text-sm font-bold text-[#1C1917] tabular-nums">
                      {current > 0 ? `${current}/5` : 'Select'}
                    </span>
                  </div>

                  <p className="text-xs text-[#57534E] leading-relaxed">{factor.description}</p>

                  <div className="flex items-center gap-1.5" role="radiogroup" aria-label={factor.label}>
                    {[1, 2, 3, 4, 5].map((starValue) => {
                      const active = starValue <= current;
                      return (
                        <button
                          key={starValue}
                          type="button"
                          onClick={() =>
                            setRatings((prev) => ({
                              ...prev,
                              [factor.key]: starValue,
                            }))
                          }
                          aria-label={`${factor.label}: ${starValue} out of 5`}
                          className={`p-2 rounded-lg border transition-colors ${
                            active
                              ? 'bg-[#D97706]/15 border-[#D97706]/40 text-[#B45309]'
                              : 'bg-white border-[#1C1917]/10 text-[#A8A29E] hover:text-[#D97706]'
                          }`}
                        >
                          <Star className={`w-5 h-5 ${active ? 'fill-[#D97706] text-[#D97706]' : ''}`} />
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#78716C]">
                    <span>1: {factor.rubricLow}</span>
                    <span className="text-right">5: {factor.rubricHigh}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Live Calculated Score Preview */}
          <div className="bg-[#F3F1EC] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-[#57534E]">
                Live Weighted Score Preview for This Audit
              </p>
              <p className="text-xs text-[#57534E] mt-0.5">
                {allRated
                  ? `(0.40×${ratings.water_cleanliness}) + (0.25×${ratings.covered_food}) + (0.20×${ratings.glove_usage}) + (0.15×${ratings.surroundings})`
                  : 'Select a 1–5 rating for all four hygiene criteria to calculate your weighted score.'}
              </p>
            </div>
            <div className="font-mono text-2xl font-bold text-[#1C1917] tabular-nums shrink-0">
              {previewScore !== null ? `${previewScore.toFixed(2)} / 5.00` : '— / 5.00'}
            </div>
          </div>
        </div>

        {/* Observation & Photo Upload */}
        <div className="space-y-5 pt-2 border-t border-[#1C1917]/10">
          <div>
            <label htmlFor="review-observation" className="block text-sm font-semibold text-[#1C1917] mb-1.5">
              Factual Sanitation Observation (optional)
            </label>
            <textarea
              id="review-observation"
              rows={3}
              maxLength={600}
              value={observation}
              onChange={(e) => setObservation(e.target.value)}
              placeholder="Describe visible practices (e.g., RO water jar visible, glass sneeze guard closed, serving tongs used)..."
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="review-photo" className="block text-sm font-semibold text-[#1C1917]">
              Upload Stall Photograph (optional, JPG/PNG/WebP up to 5MB)
            </label>
            <div className="flex flex-wrap items-center gap-4">
              <label className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#1C1917] bg-[#F3F1EC] border border-[#1C1917]/15 rounded-lg hover:bg-[#E7E5E4] cursor-pointer">
                <Upload className="w-4 h-4" />
                <span>{photo ? 'Change Photo' : 'Choose Image'}</span>
                <input
                  id="review-photo"
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) => setPhoto(e.target.files?.[0] || null)}
                  className="sr-only"
                />
              </label>
              {photo && <span className="text-xs text-[#57534E]">{photo.name}</span>}
            </div>
            {photoPreview && (
              <img
                src={photoPreview}
                alt="Selected stall preview"
                className="w-44 aspect-[4/3] object-cover rounded-lg border border-[#1C1917]/10 mt-2"
              />
            )}
          </div>
        </div>

        <div className="pt-4 border-t border-[#1C1917]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs text-[#57534E] max-w-md">
            Limitation notice: ChaatMap operates without user login accounts, so single-visit duplicate prevention cannot be cryptographically guaranteed across sessions.
          </p>
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-3 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] disabled:opacity-60 transition-colors whitespace-nowrap"
          >
            {submitting ? 'Saving Review...' : 'Submit Hygiene Review'}
          </button>
        </div>
      </form>
    </div>
  );
}
