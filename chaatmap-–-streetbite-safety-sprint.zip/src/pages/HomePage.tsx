import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, MapPin, Route, Search, ShieldCheck, Star } from 'lucide-react';
import { fetchCommunityStats, fetchFoodTrails, fetchVendors } from '../api/client';
import { CommunityStats, FoodTrail, Vendor } from '../types/chaatmap';
import { formatScore } from '../utils/hygiene';
import { FallbackImage } from '../components/FallbackImage';
import { VendorCard } from '../components/VendorCard';

const CATEGORY_CARDS = [
  {
    name: 'Pani Puri',
    subtitle: 'RO-water golgappa & spiced mint',
    image: '/src/assets/images/food_pani_puri_1795195067249.jpg',
  },
  {
    name: 'Dosa',
    subtitle: 'Crisp ghee masala & tiffin carts',
    image: '/src/assets/images/food_masala_dosa_1795195066358.jpg',
  },
  {
    name: 'Chaat',
    subtitle: 'Dahi papdi, aloo tikki & bhel',
    image: '/src/assets/images/food_chaat_platter_1795195065896.jpg',
  },
  {
    name: 'Pav Bhaji',
    subtitle: 'Buttered tawa bhaji & toasted pav',
    image: '/src/assets/images/food_pav_bhaji_1795195066835.jpg',
  },
  {
    name: 'Momos',
    subtitle: 'Steamed dumplings & chili dip',
    image: '/src/assets/images/food_steamed_momos_1795195066452.jpg',
  },
  {
    name: 'Mirchi Bajji',
    subtitle: 'Stuffed chili fritters & punugulu',
    image: '/src/assets/images/food_mirchi_bajji_1795195067283.jpg',
  },
];

export function HomePage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [locality, setLocality] = useState('All');
  const [cuisine, setCuisine] = useState('All');

  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [trails, setTrails] = useState<FoodTrail[]>([]);
  const [stats, setStats] = useState<CommunityStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    async function loadHome() {
      try {
        setLoading(true);
        const [vendorList, trailList, communityStats] = await Promise.all([
          fetchVendors({ sort: 'hygiene' }),
          fetchFoodTrails(),
          fetchCommunityStats(),
        ]);
        if (!active) return;
        setVendors(vendorList);
        setTrails(trailList);
        setStats(communityStats);
      } catch (err) {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Failed to load ChaatMap data.');
      } finally {
        if (active) setLoading(false);
      }
    }
    loadHome();
    return () => {
      active = false;
    };
  }, []);

  function handleExploreSubmit(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (search.trim()) params.set('search', search.trim());
    if (locality !== 'All') params.set('locality', locality);
    if (cuisine !== 'All') params.set('cuisine', cuisine);
    const qs = params.toString();
    navigate(`/explore${qs ? `?${qs}` : ''}`);
  }

  const topVendors = useMemo(() => vendors.slice(0, 3), [vendors]);

  const localityHubs = useMemo(() => {
    const counts = new Map<string, { count: number; avgScore: number }>();
    for (const v of vendors) {
      const current = counts.get(v.locality) || { count: 0, avgScore: 0 };
      counts.set(v.locality, {
        count: current.count + 1,
        avgScore: current.avgScore + v.hygiene_score,
      });
    }
    return Array.from(counts.entries())
      .map(([name, info]) => ({
        name,
        count: info.count,
        avgScore: Math.round((info.avgScore / info.count) * 10) / 10,
      }))
      .sort((a, b) => b.count - a.count || b.avgScore - a.avgScore);
  }, [vendors]);

  return (
    <div className="space-y-20 pb-8">
      {/* Hero Section */}
      <section className="border-b border-[#1C1917]/10 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
              <div className="space-y-4">
                <p className="text-xs font-semibold tracking-wide text-[#B91C1C]">
                  Discover Street Food. Trust the Hygiene. · Hyderabad Guide
                </p>
                <h1 className="font-display text-3xl sm:text-4xl lg:text-[3.1rem] font-bold tracking-tight text-[#1C1917] leading-[1.08] [text-wrap:balance]">
                  Your Favourite Street Food, With More Confidence.
                </h1>
                <p className="text-base sm:text-lg text-[#57534E] leading-relaxed max-w-xl">
                  Discover local street food vendors, explore their signature delicacies, and make informed choices using community-powered hygiene ratings.
                </p>
              </div>

              {/* Functional Hero Filter & Search Form */}
              <form
                onSubmit={handleExploreSubmit}
                className="bg-[#FAF9F6] border border-[#1C1917]/12 rounded-xl p-4 space-y-3"
              >
                <div className="relative">
                  <Search className="w-4 h-4 text-[#78716C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search stall name or dish (e.g., Pani Puri, Dosa)..."
                    aria-label="Search street food vendors or dishes"
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-[#1C1917]/15 rounded-lg text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#B91C1C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="hero-locality" className="sr-only">
                      Select Locality
                    </label>
                    <select
                      id="hero-locality"
                      value={locality}
                      onChange={(e) => setLocality(e.target.value)}
                      className="w-full px-3 py-2.5 text-sm bg-white border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
                    >
                      <option value="All">All Localities</option>
                      {(stats?.localities || ['Sindhi Colony', 'Madhapur', 'Old City', 'Ameerpet', 'Banjara Hills']).map((loc) => (
                        <option key={loc} value={loc}>
                          {loc}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="hero-cuisine" className="sr-only">
                      Select Food Specialty
                    </label>
                    <select
                      id="hero-cuisine"
                      value={cuisine}
                      onChange={(e) => setCuisine(e.target.value)}
                      className="w-full px-3 py-2.5 text-sm bg-white border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
                    >
                      <option value="All">All Specialties</option>
                      {CATEGORY_CARDS.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors whitespace-nowrap"
                  >
                    <span>Explore Street Food</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <Link
                    to="/map"
                    className="inline-flex items-center justify-center gap-1.5 px-4 py-3 text-sm font-semibold text-[#1C1917] bg-white border border-[#1C1917]/15 rounded-lg hover:bg-[#F3F1EC] transition-colors whitespace-nowrap"
                  >
                    <MapPin className="w-4 h-4 text-[#B91C1C]" />
                    <span>Open Street Map</span>
                  </Link>
                </div>
              </form>
            </div>

            <div className="lg:col-span-6">
              <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-[#1C1917]/10 bg-[#EFECE6]">
                <FallbackImage
                  src="/src/assets/images/hero_hyderabad_chaat_1795195067332.jpg"
                  alt="Hygienic Hyderabad pani puri and chaat stall with glass shield and gloved vendor"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-5 text-white">
                  <p className="text-xs font-medium text-amber-200">
                    Four-Factor Hygiene Formula · Water · Covered Display · Gloves · Surroundings
                  </p>
                  <p className="text-sm sm:text-base font-medium mt-0.5">
                    Objective sanitation audits across Hyderabad’s busiest street food corridors.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* F. Community Statistics Strip (live from SQLite) */}
          <div className="mt-10 pt-8 border-t border-[#1C1917]/10 grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="font-mono text-2xl sm:text-3xl font-bold text-[#1C1917] tabular-nums">
                {stats ? stats.total_vendors : '—'}
              </p>
              <p className="text-xs sm:text-sm text-[#57534E] mt-1">Mapped Street Vendors</p>
            </div>
            <div>
              <p className="font-mono text-2xl sm:text-3xl font-bold text-[#1C1917] tabular-nums">
                {stats ? stats.total_reviews : '—'}
              </p>
              <p className="text-xs sm:text-sm text-[#57534E] mt-1">Structured Hygiene Reviews</p>
            </div>
            <div>
              <p className="font-mono text-2xl sm:text-3xl font-bold text-[#15803D] tabular-nums">
                {stats ? stats.verified_vendors : '—'}
              </p>
              <p className="text-xs sm:text-sm text-[#57534E] mt-1">FSSAI Sample Verified Stalls</p>
            </div>
            <div>
              <p className="font-mono text-2xl sm:text-3xl font-bold text-[#B91C1C] tabular-nums">
                {stats ? stats.total_trails : '—'}
              </p>
              <p className="text-xs sm:text-sm text-[#57534E] mt-1">Curated Food Trails</p>
            </div>
          </div>
        </div>
      </section>

      {error && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-4 rounded-xl border border-[#B91C1C]/30 bg-[#B91C1C]/5 text-sm text-[#991B1B]">
            {error}
          </div>
        </div>
      )}

      {/* A. Popular Food Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1C1917]">
              Popular Street Food Specialties
            </h2>
            <p className="text-sm text-[#57534E] mt-1">
              Browse Hyderabad vendors by dish specialty and compare sanitation scores.
            </p>
          </div>
          <Link
            to="/explore"
            className="text-sm font-semibold text-[#B91C1C] hover:underline inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>View all vendors</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {CATEGORY_CARDS.map((cat) => (
            <Link
              key={cat.name}
              to={`/explore?cuisine=${encodeURIComponent(cat.name)}`}
              className="group bg-white border border-[#1C1917]/10 rounded-xl overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all duration-200"
            >
              <div className="aspect-[4/3] bg-[#EFECE6] overflow-hidden">
                <FallbackImage
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-3.5">
                <h3 className="font-display text-sm font-semibold text-[#1C1917] group-hover:text-[#B91C1C] transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs text-[#57534E] mt-0.5 line-clamp-2">{cat.subtitle}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* B. Top Hygiene-Rated Vendors */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1C1917]">
              Top Hygiene-Rated Vendors
            </h2>
            <p className="text-sm text-[#57534E] mt-1">
              Ranked by weighted community audits across water quality, covered storage, gloves, and surroundings.
            </p>
          </div>
          <Link
            to="/vendor-of-the-month"
            className="text-sm font-semibold text-[#B91C1C] hover:underline inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>Vendor of the Month</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-96 rounded-xl bg-[#EFECE6] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topVendors.map((vendor) => (
              <VendorCard key={vendor.id} vendor={vendor} />
            ))}
          </div>
        )}
      </section>

      {/* C. Popular Food Destinations & D. Recommended Food Trails */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Popular Destinations */}
        <div className="lg:col-span-5 space-y-5">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#1C1917]">
              Popular Food Destinations
            </h2>
            <p className="text-sm text-[#57534E] mt-1">
              Explore street-food hubs across Hyderabad and Secunderabad.
            </p>
          </div>

          <div className="bg-white border border-[#1C1917]/10 rounded-xl divide-y divide-[#1C1917]/8">
            {localityHubs.slice(0, 6).map((hub) => (
              <Link
                key={hub.name}
                to={`/explore?locality=${encodeURIComponent(hub.name)}`}
                className="flex items-center justify-between px-4 py-3.5 hover:bg-[#FAF9F6] transition-colors group"
              >
                <div>
                  <p className="text-sm font-semibold text-[#1C1917] group-hover:text-[#B91C1C] transition-colors">
                    {hub.name}
                  </p>
                  <p className="text-xs text-[#57534E] tabular-nums">
                    {hub.count} {hub.count === 1 ? 'vendor' : 'vendors'} mapped
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center gap-1 text-xs font-mono font-semibold text-[#1C1917] tabular-nums">
                    <Star className="w-3.5 h-3.5 fill-[#D97706] text-[#D97706]" />
                    {hub.avgScore.toFixed(1)} avg
                  </span>
                  <ArrowRight className="w-4 h-4 text-[#78716C] group-hover:text-[#B91C1C]" />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recommended Food Trails */}
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#1C1917]">
                Recommended Food Trails
              </h2>
              <p className="text-sm text-[#57534E] mt-1">
                Walking routes grouping verified, high-hygiene stalls with offline guide saving.
              </p>
            </div>
            <Link
              to="/trails"
              className="text-sm font-semibold text-[#B91C1C] hover:underline whitespace-nowrap"
            >
              All trails
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {trails.slice(0, 4).map((trail) => (
              <Link
                key={trail.id}
                to={`/trails?trailId=${trail.id}`}
                className="bg-white border border-[#1C1917]/10 rounded-xl p-5 flex flex-col justify-between gap-4 hover:-translate-y-0.5 hover:shadow-md transition-all"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#57534E]">
                    <span>{trail.locality}</span>
                    <span className="font-mono font-semibold text-[#15803D] tabular-nums">
                      {trail.average_hygiene_score.toFixed(1)}/5 avg
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-[#1C1917]">
                    {trail.name}
                  </h3>
                  <p className="text-xs text-[#57534E] line-clamp-2 leading-relaxed">
                    {trail.description}
                  </p>
                </div>
                <div className="pt-3 border-t border-[#1C1917]/8 flex items-center justify-between text-xs font-medium text-[#1C1917]">
                  <span className="inline-flex items-center gap-1.5">
                    <Route className="w-3.5 h-3.5 text-[#B91C1C]" />
                    {trail.vendor_count} stalls · {trail.estimated_duration}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#B91C1C]" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* E. How ChaatMap Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-[#1C1917]/10 rounded-xl p-6 sm:p-10 space-y-8">
          <div className="max-w-2xl">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1C1917]">
              How ChaatMap Works
            </h2>
            <p className="text-sm text-[#57534E] mt-2 leading-relaxed">
              Instead of vague taste-only star ratings, ChaatMap scores every stall using four visible sanitation checks weighted by food-safety impact.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-2">
            <div className="space-y-2">
              <p className="font-mono text-xs font-semibold text-[#B91C1C]">01. Inspect Four Factors</p>
              <h3 className="font-display text-lg font-semibold text-[#1C1917]">
                Objective Sanitation Checklist
              </h3>
              <p className="text-sm text-[#57534E] leading-relaxed">
                Diners rate Clean/RO Water (40%), Covered Food Display (25%), Gloves & Headgear (20%), and Surroundings Cleanliness (15%) from 1 to 5.
              </p>
            </div>

            <div className="space-y-2">
              <p className="font-mono text-xs font-semibold text-[#B91C1C]">02. Live Weighted Score</p>
              <h3 className="font-display text-lg font-semibold text-[#1C1917]">
                Transparent Hygiene Trust Score
              </h3>
              <p className="text-sm text-[#57534E] leading-relaxed">
                Every submitted audit immediately recalculates the stall’s Hygiene Trust Score in SQLite and updates directories, detail pages, and map pins.
              </p>
            </div>

            <div className="space-y-2">
              <p className="font-mono text-xs font-semibold text-[#B91C1C]">03. Walk & Save Offline</p>
              <h3 className="font-display text-lg font-semibold text-[#1C1917]">
                Real-Time Status & Trails
              </h3>
              <p className="text-sm text-[#57534E] leading-relaxed">
                Check Open/Closed updates with timestamps, spot FSSAI indicators, and save curated food trails offline before heading out.
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-[#1C1917]/10 flex flex-wrap items-center justify-between gap-4">
            <div className="inline-flex items-center gap-2 text-xs text-[#57534E]">
              <ShieldCheck className="w-4 h-4 text-[#15803D]" />
              <span>Help keep Hyderabad street food safer by contributing an inspection after your next visit.</span>
            </div>
            <Link
              to="/review"
              className="px-4 py-2 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors whitespace-nowrap"
            >
              Submit Hygiene Review
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
