import { Link } from 'react-router-dom';
import { Award, CheckCircle2, MapPin, ShieldCheck } from 'lucide-react';
import { HYGIENE_FACTOR_META } from '../utils/hygiene';

export function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      <section className="space-y-4">
        <p className="text-xs font-semibold text-[#B91C1C]">
          ChaatMap – StreetBite Safety Sprint
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1C1917]">
          Making Street Food Discovery Safer and Transparent
        </h1>
        <p className="text-base text-[#44403C] leading-relaxed">
          Street food is the culinary heart of Indian cities, yet diners frequently worry about waterborne contamination, uncovered food trays, bare-hand handling, and surrounding sanitation. Conventional restaurant platforms focus on taste and ambience while ignoring street-specific hygiene indicators.
        </p>
        <p className="text-base text-[#44403C] leading-relaxed">
          ChaatMap replaces guesswork with a structured, community-audited four-factor Hygiene Trust Score designed specifically for roadside stalls and pushcarts.
        </p>
      </section>

      {/* Formula Section */}
      <section className="bg-white border border-[#1C1917]/10 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="space-y-2">
          <h2 className="font-display text-2xl font-bold text-[#1C1917]">
            The Weighted Hygiene Trust Formula
          </h2>
          <p className="text-sm text-[#57534E]">
            Every community audit evaluates four observable practices on a 1–5 scale, weighted by food-safety impact:
          </p>
        </div>

        <div className="bg-[#FAF9F6] border border-[#1C1917]/10 rounded-lg p-4 font-mono text-xs sm:text-sm text-[#1C1917]">
          Hygiene Score = (0.40 × Water Cleanliness) + (0.25 × Covered Food) + (0.20 × Glove Usage) + (0.15 × Surroundings)
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {HYGIENE_FACTOR_META.map((factor) => (
            <div key={factor.key} className="p-4 rounded-lg border border-[#1C1917]/10 space-y-1.5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[#1C1917]">{factor.label}</h3>
                <span className="font-mono text-xs font-bold text-[#B91C1C] tabular-nums">
                  {factor.weightPercent}%
                </span>
              </div>
              <p className="text-xs text-[#57534E] leading-relaxed">{factor.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FSSAI & Data Transparency */}
      <section id="fssai" className="bg-white border border-[#1C1917]/10 rounded-xl p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#15803D]" />
          <h2 className="font-display text-2xl font-bold text-[#1C1917]">
            Data Transparency & Limitations
          </h2>
        </div>

        <ul className="space-y-4 text-sm text-[#44403C] leading-relaxed">
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#15803D] shrink-0 mt-1" />
            <span>
              <strong>Illustrative FSSAI Verification Badges:</strong> Verified badges reflect stored flags in ChaatMap’s sample SQLite database. ChaatMap does not connect to an official government FSSAI registry, and seeded vendor records are illustrative demonstration entries for Hyderabad.
            </span>
          </li>
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#15803D] shrink-0 mt-1" />
            <span>
              <strong>Live Availability Freshness:</strong> Crowd-sourced Open/Closed updates always show their exact update timestamp. Reports older than 24 hours are explicitly flagged as unconfirmed rather than presented as live status.
            </span>
          </li>
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#15803D] shrink-0 mt-1" />
            <span>
              <strong>Review Accountability:</strong> Without mandatory user sign-in accounts, duplicate prevention is assisted in-browser per session rather than strictly enforced across accounts.
            </span>
          </li>
        </ul>

        <div className="pt-4 border-t border-[#1C1917]/10 flex flex-wrap gap-3">
          <Link
            to="/explore"
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B]"
          >
            <MapPin className="w-4 h-4" />
            <span>Explore Hyderabad Vendors</span>
          </Link>
          <Link
            to="/vendor-of-the-month"
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-[#1C1917] bg-[#F3F1EC] rounded-lg hover:bg-[#E7E5E4]"
          >
            <Award className="w-4 h-4 text-[#B91C1C]" />
            <span>View Vendor of the Month</span>
          </Link>
        </div>
      </section>
    </div>
  );
}
