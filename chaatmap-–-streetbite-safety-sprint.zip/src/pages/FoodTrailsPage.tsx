import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  BookmarkCheck,
  BookmarkPlus,
  Clock,
  Info,
  MapPin,
  Route,
  Star,
  Trash2,
  WifiOff,
} from 'lucide-react';
import { fetchFoodTrails } from '../api/client';
import { FoodTrail } from '../types/chaatmap';
import { formatRelativeTime, formatScore, formatTime12h } from '../utils/hygiene';
import {
  getOfflineTrails,
  OfflineSavedTrail,
  removeOfflineTrail,
  saveTrailOffline,
} from '../utils/offlineTrails';
import { InteractiveVendorMap } from '../components/InteractiveVendorMap';
import { FssaiBadge } from '../components/FssaiBadge';

export function FoodTrailsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const requestedTrailId = Number(searchParams.get('trailId') || 0);

  const [trails, setTrails] = useState<FoodTrail[]>([]);
  const [selectedTrailId, setSelectedTrailId] = useState<number>(requestedTrailId || 0);
  const [offlineTrails, setOfflineTrails] = useState<OfflineSavedTrail[]>(() => getOfflineTrails());
  const [showOfflineView, setShowOfflineView] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saveNotice, setSaveNotice] = useState('');

  useEffect(() => {
    let active = true;
    fetchFoodTrails()
      .then((list) => {
        if (!active) return;
        setTrails(list);
        if (requestedTrailId && list.some((t) => t.id === requestedTrailId)) {
          setSelectedTrailId(requestedTrailId);
        } else if (list.length > 0) {
          setSelectedTrailId(list[0].id);
        }
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load food trails.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [requestedTrailId]);

  const activeTrail = trails.find((t) => t.id === selectedTrailId) || trails[0] || null;
  const isSaved = activeTrail ? offlineTrails.some((t) => t.id === activeTrail.id) : false;

  function handleSelectTrail(id: number) {
    setSelectedTrailId(id);
    setShowOfflineView(false);
    setSaveNotice('');
    setSearchParams({ trailId: String(id) }, { replace: true });
  }

  function handleSaveOffline() {
    if (!activeTrail) return;
    const updated = saveTrailOffline(activeTrail);
    setOfflineTrails(updated);
    setSaveNotice(`"${activeTrail.name}" saved locally for offline access.`);
  }

  function handleRemoveOffline(trailId: number) {
    const updated = removeOfflineTrail(trailId);
    setOfflineTrails(updated);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1C1917]">
            Curated Hygiene Food Trails
          </h1>
          <p className="text-sm sm:text-base text-[#57534E] max-w-2xl">
            Walkable clusters of high-hygiene Hyderabad stalls. Save any trail locally before heading into crowded market lanes with weak signal.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowOfflineView((prev) => !prev)}
          className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap self-start ${
            showOfflineView
              ? 'bg-[#1C1917] text-white border-[#1C1917]'
              : 'bg-white text-[#1C1917] border-[#1C1917]/15 hover:bg-[#F3F1EC]'
          }`}
        >
          <WifiOff className="w-4 h-4" />
          <span>Saved Offline Guides ({offlineTrails.length})</span>
        </button>
      </div>

      {/* Offline Saved Guides View */}
      {showOfflineView ? (
        <section className="space-y-6">
          <div className="bg-[#D97706]/10 border border-[#D97706]/25 rounded-xl p-4 flex items-start gap-3 text-xs text-[#78350F]">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <p>
              Offline guides are stored in your browser’s local storage with vendor landmarks, GPS coordinates, signature dishes, and hygiene scores at the time of saving. Stored ratings and open/closed status may become outdated if vendors update later.
            </p>
          </div>

          {offlineTrails.length === 0 ? (
            <div className="bg-white border border-[#1C1917]/10 rounded-xl p-10 text-center space-y-3">
              <p className="font-display text-lg font-semibold text-[#1C1917]">
                No trails saved for offline access yet
              </p>
              <p className="text-sm text-[#57534E]">
                Select any food trail and click “Save Trail Offline” to cache its stops, dishes, and landmarks locally.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {offlineTrails.map((saved) => (
                <article
                  key={saved.id}
                  className="bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-4"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-[#57534E]">
                        {saved.locality} · Saved {formatRelativeTime(saved.saved_at)}
                      </p>
                      <h2 className="font-display text-xl font-bold text-[#1C1917] mt-0.5">
                        {saved.name}
                      </h2>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveOffline(saved.id)}
                      aria-label={`Remove ${saved.name} from offline storage`}
                      className="p-2 text-[#78716C] hover:text-[#B91C1C] rounded-lg hover:bg-[#FAF9F6]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-xs text-[#57534E] leading-relaxed">{saved.description}</p>

                  <div className="divide-y divide-[#1C1917]/8 border-t border-[#1C1917]/10">
                    {saved.vendors.map((v) => (
                      <div key={v.id} className="py-3 space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-semibold text-[#1C1917]">
                            {v.sequence_order}. {v.name}
                          </span>
                          <span className="font-mono text-xs font-bold text-[#15803D] tabular-nums">
                            {formatScore(v.hygiene_score)}/5
                          </span>
                        </div>
                        <p className="text-xs text-[#57534E]">
                          {v.landmark} · {formatTime12h(v.opening_time)}–{formatTime12h(v.closing_time)} · GPS:{' '}
                          <span className="font-mono">
                            {v.latitude.toFixed(4)}, {v.longitude.toFixed(4)}
                          </span>
                        </p>
                        <p className="text-xs text-[#44403C]">
                          Dishes: {v.dishes.map((d) => `${d.dish_name} (₹${d.price})`).join(', ')}
                        </p>
                      </div>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      ) : loading ? (
        <div className="h-96 rounded-xl bg-[#EFECE6] animate-pulse" />
      ) : error ? (
        <div className="p-5 rounded-xl border border-[#B91C1C]/30 bg-[#B91C1C]/5 text-sm text-[#991B1B]">
          {error}
        </div>
      ) : (
        <div className="space-y-8">
          {/* Trail Selector Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {trails.map((trail) => {
              const selected = activeTrail?.id === trail.id;
              return (
                <button
                  key={trail.id}
                  type="button"
                  onClick={() => handleSelectTrail(trail.id)}
                  className={`text-left p-5 rounded-xl border transition-all ${
                    selected
                      ? 'bg-[#1C1917] text-white border-[#1C1917] shadow-md'
                      : 'bg-white text-[#1C1917] border-[#1C1917]/10 hover:border-[#B91C1C]/50'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className={selected ? 'text-stone-300' : 'text-[#57534E]'}>
                      {trail.locality}
                    </span>
                    <span
                      className={`font-mono font-semibold tabular-nums ${
                        selected ? 'text-amber-300' : 'text-[#15803D]'
                      }`}
                    >
                      {trail.average_hygiene_score.toFixed(1)}/5 avg
                    </span>
                  </div>
                  <h2 className="font-display text-base font-bold leading-snug">{trail.name}</h2>
                  <p className={`text-xs mt-2 ${selected ? 'text-stone-300' : 'text-[#57534E]'}`}>
                    {trail.vendor_count} stalls · {trail.estimated_duration}
                  </p>
                </button>
              );
            })}
          </div>

          {activeTrail && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Trail Route Overview & Stops */}
              <div className="lg:col-span-5 bg-white border border-[#1C1917]/10 rounded-xl p-6 space-y-5">
                <div className="space-y-2 pb-4 border-b border-[#1C1917]/10">
                  <div className="flex items-center justify-between gap-2 text-xs text-[#57534E]">
                    <span className="inline-flex items-center gap-1 font-semibold text-[#B91C1C]">
                      <Route className="w-3.5 h-3.5" />
                      {activeTrail.locality}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {activeTrail.estimated_duration}
                    </span>
                  </div>

                  <h2 className="font-display text-2xl font-bold text-[#1C1917]">
                    {activeTrail.name}
                  </h2>
                  <p className="text-sm text-[#44403C] leading-relaxed">
                    {activeTrail.description}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={handleSaveOffline}
                      className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
                        isSaved
                          ? 'bg-[#15803D] text-white'
                          : 'bg-[#B91C1C] text-white hover:bg-[#991B1B]'
                      }`}
                    >
                      {isSaved ? (
                        <>
                          <BookmarkCheck className="w-4 h-4" />
                          <span>Saved Offline (Update Snapshot)</span>
                        </>
                      ) : (
                        <>
                          <BookmarkPlus className="w-4 h-4" />
                          <span>Save Trail for Offline Access</span>
                        </>
                      )}
                    </button>
                  </div>

                  {saveNotice && (
                    <p className="text-xs font-medium text-[#15803D] pt-1">{saveNotice}</p>
                  )}
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-semibold text-[#1C1917]">
                    Ordered Stops ({activeTrail.vendors.length})
                  </h3>

                  <ol className="space-y-4">
                    {activeTrail.vendors.map((stop, idx) => (
                      <li
                        key={stop.id}
                        className="pb-4 border-b border-[#1C1917]/8 last:border-b-0 last:pb-0 space-y-1.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <Link
                            to={`/vendors/${stop.id}`}
                            className="font-display text-base font-semibold text-[#1C1917] hover:text-[#B91C1C]"
                          >
                            <span className="font-mono text-xs text-[#B91C1C] mr-2">
                              0{idx + 1}.
                            </span>
                            {stop.name}
                          </Link>
                          <span className="inline-flex items-center gap-1 font-mono text-xs font-bold text-[#1C1917] tabular-nums shrink-0">
                            <Star className="w-3.5 h-3.5 fill-[#D97706] text-[#D97706]" />
                            {formatScore(stop.hygiene_score)}
                          </span>
                        </div>

                        <p className="text-xs text-[#57534E] flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 shrink-0" />
                          <span>{stop.landmark}</span>
                        </p>

                        <div className="flex items-center justify-between text-xs pt-1">
                          <span className="text-[#44403C]">
                            Try: <strong>{stop.signature_dish}</strong>
                          </span>
                          <FssaiBadge verified={stop.fssai_verified} />
                        </div>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>

              {/* Trail Route Map */}
              <div className="lg:col-span-7 space-y-3">
                <InteractiveVendorMap
                  vendors={activeTrail.vendors}
                  heightClass="h-[480px] lg:h-[580px]"
                  showTrailRoute={true}
                  showSequenceNumbers={true}
                />
                <p className="text-xs text-[#57534E] flex items-start gap-2 bg-[#F3F1EC] px-3.5 py-2.5 rounded-lg">
                  <Info className="w-4 h-4 shrink-0 mt-0.5 text-[#78716C]" />
                  <span>
                    Dashed map lines connect participating trail stops sequentially to show relative order and proximity; they do not represent turn-by-turn pedestrian sidewalk routing.
                  </span>
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
