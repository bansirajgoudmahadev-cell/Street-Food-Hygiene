import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Compass, Layers, MapPin, Search, Star } from 'lucide-react';
import { fetchNearbyVendors, fetchVendors } from '../api/client';
import { Vendor } from '../types/chaatmap';
import { formatScore } from '../utils/hygiene';
import { InteractiveVendorMap } from '../components/InteractiveVendorMap';
import { FssaiBadge } from '../components/FssaiBadge';
import { AvailabilityTag } from '../components/AvailabilityTag';

export function MapPage() {
  const [searchParams] = useSearchParams();
  const initialVendorId = Number(searchParams.get('vendorId') || 0) || null;

  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedVendorId, setSelectedVendorId] = useState<number | null>(initialVendorId);
  const [locality, setLocality] = useState('All');
  const [search, setSearch] = useState('');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [clustering, setClustering] = useState(false);
  const [nearbyActive, setNearbyActive] = useState(false);
  const [nearbyMessage, setNearbyMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        setLoading(true);
        const data = await fetchVendors({ sort: 'hygiene' });
        if (!active) return;
        setVendors(data);
        if (initialVendorId) {
          setSelectedVendorId(initialVendorId);
        } else if (data.length > 0) {
          setSelectedVendorId(data[0].id);
        }
      } catch (err) {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Unable to load vendor map.');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => {
      active = false;
    };
  }, [initialVendorId]);

  const localities = useMemo(
    () => ['All', ...Array.from(new Set(vendors.map((v) => v.locality))).sort()],
    [vendors]
  );

  const filteredVendors = useMemo(() => {
    const q = search.trim().toLowerCase();
    return vendors.filter((v) => {
      if (locality !== 'All' && v.locality !== locality) return false;
      if (verifiedOnly && !v.fssai_verified) return false;
      if (q) {
        const hit =
          v.name.toLowerCase().includes(q) ||
          v.locality.toLowerCase().includes(q) ||
          v.landmark.toLowerCase().includes(q) ||
          v.cuisine.toLowerCase().includes(q) ||
          v.dishes.some((d) => d.dish_name.toLowerCase().includes(q));
        if (!hit) return false;
      }
      return true;
    });
  }, [vendors, locality, verifiedOnly, search]);

  async function handleFindNearby() {
    setNearbyMessage('');
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const nearby = await fetchNearbyVendors(pos.coords.latitude, pos.coords.longitude, 25);
            if (nearby.length > 0) {
              setVendors(nearby);
              setSelectedVendorId(nearby[0].id);
              setNearbyActive(true);
              setNearbyMessage('Sorted by distance from your browser GPS location.');
            } else {
              // Fallback to Hyderabad Sindhi Colony hub if browser GPS is far outside Hyderabad
              const hydNearby = await fetchNearbyVendors(17.4415, 78.4810, 25);
              setVendors(hydNearby);
              setNearbyActive(true);
              setNearbyMessage('Browser GPS is outside Hyderabad; sorted from Central Hyderabad (Sindhi Colony).');
            }
          } catch {
            setNearbyMessage('Unable to compute nearby distances.');
          }
        },
        async () => {
          const hydNearby = await fetchNearbyVendors(17.4415, 78.4810, 25);
          setVendors(hydNearby);
          setNearbyActive(true);
          setNearbyMessage('Location access declined; sorted from Central Hyderabad (Sindhi Colony).');
        },
        { timeout: 5000 }
      );
    } else {
      const hydNearby = await fetchNearbyVendors(17.4415, 78.4810, 25);
      setVendors(hydNearby);
      setNearbyActive(true);
      setNearbyMessage('Sorted from Central Hyderabad (Sindhi Colony).');
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#1C1917]">
            Interactive Hyderabad Street Food Map
          </h1>
          <p className="text-sm text-[#57534E] mt-1">
            Click any food-cart pin to inspect signature dishes, Hygiene Trust Scores, and FSSAI verification status.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleFindNearby}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#1C1917] bg-white border border-[#1C1917]/15 rounded-lg hover:bg-[#F3F1EC] transition-colors whitespace-nowrap"
          >
            <Compass className="w-4 h-4 text-[#B91C1C]" />
            <span>{nearbyActive ? 'Refresh Nearby Sort' : 'Sort Nearby'}</span>
          </button>

          <button
            type="button"
            onClick={() => setClustering((c) => !c)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap ${
              clustering
                ? 'bg-[#1C1917] text-white border-[#1C1917]'
                : 'bg-white text-[#1C1917] border-[#1C1917]/15 hover:bg-[#F3F1EC]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{clustering ? 'Locality Clusters: On' : 'Locality Clusters: Off'}</span>
          </button>
        </div>
      </div>

      {/* Map Filter Toolbar */}
      <div className="bg-white border border-[#1C1917]/10 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
        <div className="sm:col-span-5 relative">
          <Search className="w-4 h-4 text-[#78716C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search vendor, dish, or landmark on map..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
          />
        </div>

        <div className="sm:col-span-4">
          <select
            value={locality}
            onChange={(e) => setLocality(e.target.value)}
            aria-label="Filter map by locality"
            className="w-full px-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
          >
            {localities.map((loc) => (
              <option key={loc} value={loc}>
                {loc === 'All' ? 'All Hyderabad Localities' : loc}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-3 flex items-center justify-between sm:justify-end gap-3">
          <label className="inline-flex items-center gap-2 text-xs font-semibold text-[#1C1917] cursor-pointer">
            <input
              type="checkbox"
              checked={verifiedOnly}
              onChange={(e) => setVerifiedOnly(e.target.checked)}
              className="w-4 h-4 accent-[#15803D]"
            />
            <span>Verified Only</span>
          </label>
          <span className="font-mono text-xs text-[#57534E] tabular-nums">
            {filteredVendors.length} pins
          </span>
        </div>
      </div>

      {nearbyMessage && (
        <p className="text-xs text-[#57534E] bg-[#F3F1EC] px-3 py-2 rounded-lg">
          {nearbyMessage}
        </p>
      )}

      {error && (
        <div className="p-4 rounded-xl border border-[#B91C1C]/30 bg-[#B91C1C]/5 text-sm text-[#991B1B]">
          {error}
        </div>
      )}

      {/* Main Map + Synced Vendor Sidebar */}
      {loading ? (
        <div className="h-[540px] rounded-xl bg-[#EFECE6] animate-pulse" />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8">
            <InteractiveVendorMap
              vendors={filteredVendors}
              selectedVendorId={selectedVendorId}
              onSelectVendor={(v) => setSelectedVendorId(v.id)}
              heightClass="h-[460px] lg:h-[600px]"
              enableClustering={clustering}
            />
          </div>

          <aside className="lg:col-span-4 bg-white border border-[#1C1917]/10 rounded-xl overflow-hidden flex flex-col lg:h-[600px]">
            <div className="px-4 py-3.5 border-b border-[#1C1917]/10 bg-[#FAF9F6] flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-[#1C1917]">
                Stalls on Map ({filteredVendors.length})
              </h2>
              <span className="text-xs text-[#57534E]">Click to locate</span>
            </div>

            {filteredVendors.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#57534E]">
                No vendors match this map filter.
              </div>
            ) : (
              <div className="divide-y divide-[#1C1917]/8 overflow-y-auto flex-1">
                {filteredVendors.map((vendor) => {
                  const isSelected = vendor.id === selectedVendorId;
                  return (
                    <div
                      key={vendor.id}
                      onClick={() => setSelectedVendorId(vendor.id)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          setSelectedVendorId(vendor.id);
                        }
                      }}
                      className={`p-4 cursor-pointer transition-colors space-y-2 ${
                        isSelected ? 'bg-[#B91C1C]/6' : 'hover:bg-[#FAF9F6]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs text-[#57534E]">
                            {vendor.locality} · {vendor.cuisine}
                            {vendor.distance_km !== undefined && (
                              <span className="font-mono ml-1.5 text-[#B91C1C]">
                                ({vendor.distance_km} km)
                              </span>
                            )}
                          </p>
                          <h3 className="font-display text-sm font-semibold text-[#1C1917] mt-0.5">
                            {vendor.name}
                          </h3>
                        </div>
                        <span className="inline-flex items-center gap-1 font-mono text-xs font-bold text-[#1C1917] tabular-nums shrink-0">
                          <Star className="w-3.5 h-3.5 fill-[#D97706] text-[#D97706]" />
                          {formatScore(vendor.hygiene_score)}
                        </span>
                      </div>

                      <p className="text-xs text-[#57534E] flex items-center gap-1">
                        <MapPin className="w-3 h-3 shrink-0" />
                        <span className="truncate">{vendor.landmark}</span>
                      </p>

                      <div className="flex items-center justify-between pt-1">
                        <FssaiBadge verified={vendor.fssai_verified} />
                        <div className="flex items-center gap-3">
                          <AvailabilityTag
                            status={vendor.availability_status}
                            updatedAt={vendor.availability_updated_at}
                            showTimestamp={false}
                          />
                          <Link
                            to={`/vendors/${vendor.id}`}
                            onClick={(e) => e.stopPropagation()}
                            className="text-xs font-semibold text-[#B91C1C] hover:underline whitespace-nowrap"
                          >
                            Details
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
