import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react';
import { fetchCommunityStats, fetchVendors } from '../api/client';
import { Vendor } from '../types/chaatmap';
import { VendorCard } from '../components/VendorCard';

const CUISINES = ['All', 'Pani Puri', 'Dosa', 'Chaat', 'Pav Bhaji', 'Momos', 'Mirchi Bajji'];
const DEFAULT_LOCALITIES = [
  'All',
  'Sindhi Colony',
  'Old City',
  'Madhapur',
  'Ameerpet',
  'Banjara Hills',
  'Tank Bund',
  'Kukatpally',
  'Dilsukhnagar',
];

export function ExplorePage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [locality, setLocality] = useState(searchParams.get('locality') || 'All');
  const [cuisine, setCuisine] = useState(searchParams.get('cuisine') || 'All');
  const [minHygiene, setMinHygiene] = useState<number>(Number(searchParams.get('minHygiene') || 0));
  const [fssaiOnly, setFssaiOnly] = useState(searchParams.get('fssaiOnly') === 'true');
  const [sort, setSort] = useState<'hygiene' | 'price_asc' | 'price_desc' | 'popularity'>(
    (searchParams.get('sort') as any) || 'hygiene'
  );

  const [localities, setLocalities] = useState<string[]>(DEFAULT_LOCALITIES);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Sync state when URL query changes from navbar/home links
  useEffect(() => {
    setSearch(searchParams.get('search') || '');
    setLocality(searchParams.get('locality') || 'All');
    setCuisine(searchParams.get('cuisine') || 'All');
    setMinHygiene(Number(searchParams.get('minHygiene') || 0));
    setFssaiOnly(searchParams.get('fssaiOnly') === 'true');
  }, [searchParams]);

  useEffect(() => {
    fetchCommunityStats()
      .then((s) => {
        if (s.localities?.length) {
          setLocalities(['All', ...s.localities]);
        }
      })
      .catch(() => {
        // Keep default localities if stats request fails
      });
  }, []);

  useEffect(() => {
    let active = true;
    const timer = setTimeout(async () => {
      try {
        setLoading(true);
        setError('');
        const list = await fetchVendors({
          locality,
          cuisine,
          minHygiene,
          fssaiOnly,
          search,
          sort,
        });
        if (!active) return;
        setVendors(list);
      } catch (err) {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Unable to load vendor directory.');
      } finally {
        if (active) setLoading(false);
      }
    }, 150);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [locality, cuisine, minHygiene, fssaiOnly, search, sort]);

  function updateQueryParam(key: string, value: string) {
    const next = new URLSearchParams(searchParams);
    if (!value || value === 'All' || value === '0' || value === 'false') {
      next.delete(key);
    } else {
      next.set(key, value);
    }
    setSearchParams(next, { replace: true });
  }

  function resetAllFilters() {
    setSearch('');
    setLocality('All');
    setCuisine('All');
    setMinHygiene(0);
    setFssaiOnly(false);
    setSort('hygiene');
    setSearchParams({}, { replace: true });
  }

  const hasActiveFilters =
    Boolean(search.trim()) ||
    locality !== 'All' ||
    cuisine !== 'All' ||
    minHygiene > 0 ||
    fssaiOnly;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1C1917]">
          Street Food Vendor Directory
        </h1>
        <p className="text-sm sm:text-base text-[#57534E] max-w-2xl">
          Filter Hyderabad street stalls by locality, specialty dish, minimum Hygiene Trust Score, or FSSAI status.
        </p>
      </div>

      {/* Filter & Sort Panel */}
      <section className="bg-white border border-[#1C1917]/10 rounded-xl p-5 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-5 relative">
            <label htmlFor="directory-search" className="block text-xs font-semibold text-[#57534E] mb-1.5">
              Search Vendor or Dish
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-[#78716C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="directory-search"
                type="search"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  updateQueryParam('search', e.target.value);
                }}
                placeholder="e.g. Pani Puri, Mahalaxmi, Masala Dosa..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
              />
            </div>
          </div>

          <div className="md:col-span-3">
            <label htmlFor="directory-locality" className="block text-xs font-semibold text-[#57534E] mb-1.5">
              Locality
            </label>
            <select
              id="directory-locality"
              value={locality}
              onChange={(e) => {
                setLocality(e.target.value);
                updateQueryParam('locality', e.target.value);
              }}
              className="w-full px-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            >
              {localities.map((loc) => (
                <option key={loc} value={loc}>
                  {loc === 'All' ? 'All Localities' : loc}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label htmlFor="directory-rating" className="block text-xs font-semibold text-[#57534E] mb-1.5">
              Hygiene Rating
            </label>
            <select
              id="directory-rating"
              value={minHygiene}
              onChange={(e) => {
                const val = Number(e.target.value);
                setMinHygiene(val);
                updateQueryParam('minHygiene', String(val));
              }}
              className="w-full px-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            >
              <option value={0}>All ratings</option>
              <option value={4.5}>4.5 and above</option>
              <option value={4.0}>4.0 and above</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label htmlFor="directory-sort" className="block text-xs font-semibold text-[#57534E] mb-1.5">
              Sort By
            </label>
            <select
              id="directory-sort"
              value={sort}
              onChange={(e) => {
                const nextSort = e.target.value as any;
                setSort(nextSort);
                updateQueryParam('sort', nextSort);
              }}
              className="w-full px-3 py-2 text-sm bg-[#FAF9F6] border border-[#1C1917]/15 rounded-lg text-[#1C1917] focus:outline-none focus:border-[#B91C1C]"
            >
              <option value="hygiene">Highest Hygiene Score</option>
              <option value="popularity">Most Reviewed</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Food Specialty Segmented Filter Buttons + FSSAI Checkbox */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-[#1C1917]/8">
          <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter by food specialty">
            {CUISINES.map((item) => {
              const active = cuisine === item;
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => {
                    setCuisine(item);
                    updateQueryParam('cuisine', item);
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#B91C1C] text-white'
                      : 'bg-[#F3F1EC] text-[#44403C] hover:bg-[#E7E5E4]'
                  }`}
                >
                  {item === 'All' ? 'All Specialties' : item}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-4">
            <label className="inline-flex items-center gap-2 text-xs font-semibold text-[#1C1917] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={fssaiOnly}
                onChange={(e) => {
                  setFssaiOnly(e.target.checked);
                  updateQueryParam('fssaiOnly', e.target.checked ? 'true' : 'false');
                }}
                className="w-4 h-4 accent-[#15803D] rounded"
              />
              <span>FSSAI Verified Only</span>
            </label>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetAllFilters}
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Results Header */}
      <div className="flex items-center justify-between text-sm text-[#57534E]">
        <p className="inline-flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#78716C]" />
          <span>
            Showing <strong className="font-mono text-[#1C1917] tabular-nums">{vendors.length}</strong>{' '}
            {vendors.length === 1 ? 'vendor' : 'vendors'}
          </span>
        </p>
      </div>

      {/* Error State */}
      {error && (
        <div className="p-5 rounded-xl border border-[#B91C1C]/30 bg-[#B91C1C]/5 text-sm text-[#991B1B]">
          {error}
        </div>
      )}

      {/* Loading State */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="h-96 rounded-xl bg-[#EFECE6] animate-pulse" />
          ))}
        </div>
      ) : vendors.length === 0 ? (
        /* Clear Empty State */
        <div className="bg-white border border-[#1C1917]/10 rounded-xl p-12 text-center space-y-4">
          <h2 className="font-display text-xl font-semibold text-[#1C1917]">
            No street food vendors match these filters
          </h2>
          <p className="text-sm text-[#57534E] max-w-md mx-auto">
            Try lowering the minimum hygiene threshold, selecting another Hyderabad locality, or clearing your dish search.
          </p>
          <button
            type="button"
            onClick={resetAllFilters}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset All Filters</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vendors.map((vendor) => (
            <VendorCard key={vendor.id} vendor={vendor} />
          ))}
        </div>
      )}
    </div>
  );
}
