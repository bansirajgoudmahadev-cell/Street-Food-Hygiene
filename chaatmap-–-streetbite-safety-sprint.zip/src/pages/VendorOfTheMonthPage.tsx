import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Award, MapPin, ShieldCheck, Star } from 'lucide-react';
import { fetchFeaturedVendor } from '../api/client';
import { FeaturedVendorResponse } from '../types/chaatmap';
import { formatScore } from '../utils/hygiene';
import { FallbackImage } from '../components/FallbackImage';
import { FssaiBadge } from '../components/FssaiBadge';
import { HygieneBreakdown } from '../components/HygieneBreakdown';

export function VendorOfTheMonthPage() {
  const [data, setData] = useState<FeaturedVendorResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    fetchFeaturedVendor()
      .then((res) => {
        if (active) setData(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load featured vendor.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
        <div className="h-96 rounded-xl bg-[#EFECE6] animate-pulse" />
      </div>
    );
  }

  if (error || !data || !data.vendor) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center space-y-3">
        <h1 className="font-display text-2xl font-bold text-[#1C1917]">
          Clean Street Food Vendor of the Month
        </h1>
        <p className="text-sm text-[#B91C1C]">{error || 'No qualifying vendor available yet.'}</p>
      </div>
    );
  }

  const winner = data.vendor;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="space-y-2">
        <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#B91C1C]">
          <Award className="w-4 h-4" />
          <span>Clean Street Food Recognition · {data.recognition_month}</span>
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1C1917]">
          Clean Street Food Vendor of the Month
        </h1>
        <p className="text-sm sm:text-base text-[#57534E] max-w-2xl">
          Recognizing the Hyderabad street food vendor demonstrating consistent sanitation standards across community inspections.
        </p>
      </div>

      {/* Winner Spotlight Card */}
      <section className="bg-white border border-[#1C1917]/12 rounded-xl overflow-hidden shadow-sm">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-5 relative min-h-[300px] bg-[#EFECE6]">
            <FallbackImage
              src={winner.image}
              alt={winner.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-[#57534E]">
                  {winner.locality} · {winner.cuisine}
                </span>
                <FssaiBadge verified={winner.fssai_verified} showTooltipNote />
              </div>

              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1C1917]">
                {winner.name}
              </h2>

              <p className="text-sm text-[#57534E] flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#B91C1C]" />
                <span>{winner.landmark} — {winner.address}</span>
              </p>

              <p className="text-sm text-[#44403C] leading-relaxed">{winner.description}</p>
            </div>

            <div className="grid grid-cols-3 gap-4 py-4 border-y border-[#1C1917]/10">
              <div>
                <p className="text-xs text-[#57534E]">Hygiene Trust Score</p>
                <p className="font-mono text-2xl font-bold text-[#15803D] tabular-nums mt-0.5 flex items-center gap-1.5">
                  <Star className="w-5 h-5 fill-[#D97706] text-[#D97706]" />
                  {winner.hygiene_score.toFixed(2)}/5
                </p>
              </div>

              <div>
                <p className="text-xs text-[#57534E]">Verified Audits</p>
                <p className="font-mono text-2xl font-bold text-[#1C1917] tabular-nums mt-0.5">
                  {winner.review_count}
                </p>
              </div>

              <div>
                <p className="text-xs text-[#57534E]">Signature Delicacy</p>
                <p className="text-sm font-semibold text-[#1C1917] mt-1">
                  {winner.signature_dish}
                </p>
              </div>
            </div>

            <HygieneBreakdown factors={winner.hygiene_factors} compact />

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Link
                to={`/vendors/${winner.id}`}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg hover:bg-[#991B1B] transition-colors"
              >
                Inspect Stall Profile
              </Link>
              <Link
                to={`/map?vendorId=${winner.id}`}
                className="px-4 py-2.5 text-sm font-semibold text-[#1C1917] bg-[#F3F1EC] rounded-lg hover:bg-[#E7E5E4] transition-colors"
              >
                Locate on Map
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Transparent Selection Rule */}
      <section className="bg-[#F3F1EC] border border-[#1C1917]/10 rounded-xl p-6 space-y-2">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#1C1917]">
          <ShieldCheck className="w-4 h-4 text-[#15803D]" />
          <span>Transparent Selection Criteria</span>
        </div>
        <p className="text-sm text-[#44403C] leading-relaxed">{data.selection_rule}</p>
        <p className="text-xs text-[#57534E] tabular-nums">
          Currently {data.qualifying_count} mapped stalls meet the minimum threshold of{' '}
          {data.minimum_review_threshold} structured reviews.
        </p>
      </section>

      {/* Qualifying Runner-Ups */}
      {data.runners_up.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-xl font-bold text-[#1C1917]">
            Top Qualifying Contenders
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {data.runners_up.map((stall, index) => (
              <Link
                key={stall.id}
                to={`/vendors/${stall.id}`}
                className="bg-white border border-[#1C1917]/10 rounded-xl p-5 space-y-2 hover:-translate-y-0.5 hover:shadow-md transition-all"
              >
                <div className="flex items-center justify-between text-xs text-[#57534E]">
                  <span>#{index + 2} · {stall.locality}</span>
                  <span className="font-mono font-bold text-[#1C1917] tabular-nums">
                    {formatScore(stall.hygiene_score)}/5 ({stall.review_count} reviews)
                  </span>
                </div>
                <h3 className="font-display text-lg font-semibold text-[#1C1917]">
                  {stall.name}
                </h3>
                <p className="text-xs text-[#57534E]">{stall.signature_dish}</p>
                <div className="pt-1">
                  <FssaiBadge verified={stall.fssai_verified} />
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
