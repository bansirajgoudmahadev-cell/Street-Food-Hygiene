import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import { getDatabase } from './db/database';
import { seedDatabase } from './db/seed';
import { UPLOAD_DIR } from './utils/validation';
import { createVendorsRouter } from './routes/vendors';
import { createTrailsRouter } from './routes/trails';
import { createStatsRouter } from './routes/stats';

export function createApiApp() {
  const app = express();
  const db = getDatabase();
  seedDatabase(db);

  const corsOrigin = process.env.CORS_ORIGIN || '*';
  app.use(
    cors({
      origin: corsOrigin === '*' ? true : corsOrigin.split(',').map((s) => s.trim()),
      methods: ['GET', 'POST', 'PATCH', 'OPTIONS'],
    })
  );

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Serve user-uploaded stall photos
  app.use('/uploads', express.static(UPLOAD_DIR));

  // Health endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', service: 'chaatmap-api' });
  });

  // REST API routes
  app.use('/api/vendors', createVendorsRouter(db));
  app.use('/api/trails', createTrailsRouter(db));
  app.use('/api', createStatsRouter(db));

  // API 404 handler
  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  // Centralized error handler without leaking stack traces
  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    console.error('Unhandled API error:', err.message);
    res.status(500).json({ error: 'An unexpected server error occurred.' });
  });

  return app;
}
