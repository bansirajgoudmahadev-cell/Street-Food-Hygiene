import Database from 'better-sqlite3';
import { calculateVendorHygieneSummary, HygieneSummary } from '../utils/hygiene';

export interface DishRecord {
  id: number;
  vendor_id: number;
  dish_name: string;
  price: number;
  description: string;
}

export interface ReviewRecord {
  id: number;
  vendor_id: number;
  reviewer_name: string;
  water_cleanliness: number;
  glove_usage: number;
  covered_food: number;
  surroundings: number;
  observation: string;
  photo: string;
  created_at: string;
}

export interface VendorRow {
  id: number;
  name: string;
  description: string;
  locality: string;
  address: string;
  landmark: string;
  latitude: number;
  longitude: number;
  cuisine: string;
  price_min: number;
  price_max: number;
  opening_time: string;
  closing_time: string;
  image: string;
  fssai_verified: number;
  availability_status: 'Open' | 'Closed' | 'Unknown';
  availability_updated_at: string;
  is_pushcart: number;
  created_at: string;
}

export interface EnrichedVendor extends Omit<VendorRow, 'fssai_verified' | 'is_pushcart'> {
  fssai_verified: boolean;
  is_pushcart: boolean;
  hygiene_score: number;
  review_count: number;
  hygiene_factors: HygieneSummary;
  dishes: DishRecord[];
  signature_dish: string;
}

export function enrichVendor(db: Database.Database, vendor: VendorRow): EnrichedVendor {
  const dishes = db
    .prepare('SELECT id, vendor_id, dish_name, price, description FROM dishes WHERE vendor_id = ? ORDER BY id ASC')
    .all(vendor.id) as DishRecord[];

  const reviews = db
    .prepare('SELECT water_cleanliness, glove_usage, covered_food, surroundings FROM hygiene_reviews WHERE vendor_id = ?')
    .all(vendor.id) as {
      water_cleanliness: number;
      glove_usage: number;
      covered_food: number;
      surroundings: number;
    }[];

  const hygiene_factors = calculateVendorHygieneSummary(reviews);

  return {
    ...vendor,
    fssai_verified: vendor.fssai_verified === 1,
    is_pushcart: vendor.is_pushcart === 1,
    hygiene_score: hygiene_factors.hygiene_score,
    review_count: hygiene_factors.review_count,
    hygiene_factors,
    dishes,
    signature_dish: dishes[0]?.dish_name || vendor.cuisine,
  };
}

export function getAllEnrichedVendors(db: Database.Database): EnrichedVendor[] {
  const vendors = db.prepare('SELECT * FROM vendors ORDER BY id ASC').all() as VendorRow[];
  return vendors.map((v) => enrichVendor(db, v));
}

export function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}
