import { Router, Request, Response } from 'express';
import Database from 'better-sqlite3';
import { enrichVendor, VendorRow } from '../services/vendorService';

interface TrailRow {
  id: number;
  name: string;
  locality: string;
  description: string;
  estimated_duration: string;
}

export function createTrailsRouter(db: Database.Database): Router {
  const router = Router();

  function hydrateTrail(trail: TrailRow) {
    const stops = db
      .prepare(
        `SELECT v.*, ftv.sequence_order
         FROM food_trail_vendors ftv
         JOIN vendors v ON v.id = ftv.vendor_id
         WHERE ftv.trail_id = ?
         ORDER BY ftv.sequence_order ASC`
      )
      .all(trail.id) as (VendorRow & { sequence_order: number })[];

    const vendors = stops.map((row) => ({
      ...enrichVendor(db, row),
      sequence_order: row.sequence_order,
    }));

    const avgHygiene =
      vendors.length > 0
        ? Math.round((vendors.reduce((sum, v) => sum + v.hygiene_score, 0) / vendors.length) * 100) / 100
        : 0;

    return {
      ...trail,
      vendor_count: vendors.length,
      average_hygiene_score: avgHygiene,
      vendors,
    };
  }

  // GET /api/trails
  router.get('/', (_req: Request, res: Response) => {
    try {
      const trails = db.prepare('SELECT * FROM food_trails ORDER BY id ASC').all() as TrailRow[];
      const hydrated = trails.map(hydrateTrail);
      res.json({ count: hydrated.length, trails: hydrated });
    } catch (err) {
      console.error('Error fetching food trails:', err);
      res.status(500).json({ error: 'Unable to load food trails.' });
    }
  });

  // GET /api/trails/:id
  router.get('/:id', (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: 'Invalid trail ID.' });
      }
      const trail = db.prepare('SELECT * FROM food_trails WHERE id = ?').get(id) as TrailRow | undefined;
      if (!trail) {
        return res.status(404).json({ error: 'Food trail not found.' });
      }
      res.json({ trail: hydrateTrail(trail) });
    } catch (err) {
      console.error('Error fetching trail details:', err);
      res.status(500).json({ error: 'Unable to load food trail details.' });
    }
  });

  return router;
}
