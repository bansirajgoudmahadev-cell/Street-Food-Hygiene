import { Router, Request, Response } from 'express';
import Database from 'better-sqlite3';
import { getAllEnrichedVendors } from '../services/vendorService';

const MIN_REVIEWS_FOR_AWARD = 3;

export function createStatsRouter(db: Database.Database): Router {
  const router = Router();

  // GET /api/stats
  router.get('/stats', (_req: Request, res: Response) => {
    try {
      const vendors = getAllEnrichedVendors(db);
      const totalReviews = (db.prepare('SELECT COUNT(*) AS count FROM hygiene_reviews').get() as { count: number }).count;
      const totalTrails = (db.prepare('SELECT COUNT(*) AS count FROM food_trails').get() as { count: number }).count;
      const verifiedVendors = vendors.filter((v) => v.fssai_verified).length;
      const localities = Array.from(new Set(vendors.map((v) => v.locality))).sort();
      const cuisines = Array.from(new Set(vendors.map((v) => v.cuisine))).sort();

      res.json({
        total_vendors: vendors.length,
        total_reviews: totalReviews,
        verified_vendors: verifiedVendors,
        total_trails: totalTrails,
        localities,
        cuisines,
      });
    } catch (err) {
      console.error('Error computing stats:', err);
      res.status(500).json({ error: 'Unable to compute community statistics.' });
    }
  });

  // GET /api/featured-vendor - Clean Street Food Vendor of the Month
  router.get('/featured-vendor', (_req: Request, res: Response) => {
    try {
      const vendors = getAllEnrichedVendors(db);
      const qualifying = vendors
        .filter((v) => v.review_count >= MIN_REVIEWS_FOR_AWARD)
        .sort((a, b) => {
          if (b.hygiene_score !== a.hygiene_score) return b.hygiene_score - a.hygiene_score;
          if (a.fssai_verified !== b.fssai_verified) return a.fssai_verified ? -1 : 1;
          return b.review_count - a.review_count;
        });

      const winner = qualifying[0] || vendors[0] || null;
      const runnersUp = qualifying.slice(1, 4);

      const now = new Date();
      const recognitionMonth = now.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

      res.json({
        recognition_month: recognitionMonth,
        minimum_review_threshold: MIN_REVIEWS_FOR_AWARD,
        selection_rule: `Awarded to the vendor with the highest weighted Hygiene Trust Score among stalls with at least ${MIN_REVIEWS_FOR_AWARD} community hygiene reviews. Tie-breakers prioritize FSSAI-verified stalls followed by total review count.`,
        qualifying_count: qualifying.length,
        vendor: winner,
        runners_up: runnersUp,
      });
    } catch (err) {
      console.error('Error computing featured vendor:', err);
      res.status(500).json({ error: 'Unable to determine Vendor of the Month.' });
    }
  });

  return router;
}
