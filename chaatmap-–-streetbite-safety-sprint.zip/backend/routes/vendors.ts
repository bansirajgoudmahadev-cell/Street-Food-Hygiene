import { Router, Request, Response } from 'express';
import Database from 'better-sqlite3';
import {
  enrichVendor,
  getAllEnrichedVendors,
  haversineDistanceKm,
  VendorRow,
} from '../services/vendorService';
import {
  isValidAvailabilityStatus,
  parseCoordinate,
  parseRating,
  sanitizeText,
  uploadStallPhoto,
} from '../utils/validation';
import { calculateWeightedHygieneScore } from '../utils/hygiene';

export function createVendorsRouter(db: Database.Database): Router {
  const router = Router();

  // GET /api/vendors - filterable, searchable, sortable directory
  router.get('/', (req: Request, res: Response) => {
    try {
      const locality = sanitizeText(req.query.locality, 80);
      const cuisine = sanitizeText(req.query.cuisine, 80);
      const search = sanitizeText(req.query.search, 120).toLowerCase();
      const minHygiene = req.query.minHygiene ? Number(req.query.minHygiene) : 0;
      const fssaiOnly = req.query.fssaiOnly === 'true';
      const sort = sanitizeText(req.query.sort, 30) || 'hygiene';

      let vendors = getAllEnrichedVendors(db);

      if (locality && locality !== 'All') {
        vendors = vendors.filter((v) => v.locality.toLowerCase() === locality.toLowerCase());
      }

      if (cuisine && cuisine !== 'All') {
        vendors = vendors.filter((v) => v.cuisine.toLowerCase() === cuisine.toLowerCase());
      }

      if (Number.isFinite(minHygiene) && minHygiene > 0) {
        vendors = vendors.filter((v) => v.hygiene_score >= minHygiene);
      }

      if (fssaiOnly) {
        vendors = vendors.filter((v) => v.fssai_verified);
      }

      if (search) {
        vendors = vendors.filter(
          (v) =>
            v.name.toLowerCase().includes(search) ||
            v.locality.toLowerCase().includes(search) ||
            v.landmark.toLowerCase().includes(search) ||
            v.cuisine.toLowerCase().includes(search) ||
            v.dishes.some((d) => d.dish_name.toLowerCase().includes(search))
        );
      }

      if (sort === 'hygiene') {
        vendors.sort((a, b) => b.hygiene_score - a.hygiene_score || b.review_count - a.review_count);
      } else if (sort === 'price_asc') {
        vendors.sort((a, b) => a.price_min - b.price_min || b.hygiene_score - a.hygiene_score);
      } else if (sort === 'price_desc') {
        vendors.sort((a, b) => b.price_max - a.price_max || b.hygiene_score - a.hygiene_score);
      } else if (sort === 'popularity') {
        vendors.sort((a, b) => b.review_count - a.review_count || b.hygiene_score - a.hygiene_score);
      }

      res.json({
        count: vendors.length,
        vendors,
      });
    } catch (err) {
      console.error('Error fetching vendors:', err);
      res.status(500).json({ error: 'Unable to load street food vendors right now.' });
    }
  });

  // GET /api/vendors/search?q=...
  router.get('/search', (req: Request, res: Response) => {
    try {
      const q = sanitizeText(req.query.q, 120).toLowerCase();
      if (!q) {
        return res.json({ count: 0, vendors: [] });
      }
      const vendors = getAllEnrichedVendors(db).filter(
        (v) =>
          v.name.toLowerCase().includes(q) ||
          v.locality.toLowerCase().includes(q) ||
          v.landmark.toLowerCase().includes(q) ||
          v.cuisine.toLowerCase().includes(q) ||
          v.dishes.some((d) => d.dish_name.toLowerCase().includes(q))
      );
      res.json({ count: vendors.length, vendors });
    } catch (err) {
      console.error('Search error:', err);
      res.status(500).json({ error: 'Search failed.' });
    }
  });

  // GET /api/vendors/nearby?lat=...&lng=...&radiusKm=...
  router.get('/nearby', (req: Request, res: Response) => {
    try {
      const lat = parseCoordinate(req.query.lat, -90, 90) ?? 17.4415;
      const lng = parseCoordinate(req.query.lng, -180, 180) ?? 78.4810;
      const radiusKm = Number(req.query.radiusKm) > 0 ? Number(req.query.radiusKm) : 15;

      const vendors = getAllEnrichedVendors(db)
        .map((v) => ({
          ...v,
          distance_km: haversineDistanceKm(lat, lng, v.latitude, v.longitude),
        }))
        .filter((v) => v.distance_km <= radiusKm)
        .sort((a, b) => a.distance_km - b.distance_km);

      res.json({ center: { lat, lng }, radiusKm, count: vendors.length, vendors });
    } catch (err) {
      console.error('Nearby query error:', err);
      res.status(500).json({ error: 'Unable to find nearby vendors.' });
    }
  });

  // GET /api/vendors/:id
  router.get('/:id', (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: 'Invalid vendor ID.' });
      }

      const vendorRow = db.prepare('SELECT * FROM vendors WHERE id = ?').get(id) as VendorRow | undefined;
      if (!vendorRow) {
        return res.status(404).json({ error: 'Vendor not found.' });
      }

      const enriched = enrichVendor(db, vendorRow);
      const reviews = db
        .prepare('SELECT * FROM hygiene_reviews WHERE vendor_id = ? ORDER BY datetime(created_at) DESC, id DESC')
        .all(id);
      const photos = db
        .prepare('SELECT * FROM vendor_photos WHERE vendor_id = ? ORDER BY datetime(created_at) DESC, id DESC')
        .all(id);

      res.json({
        vendor: enriched,
        reviews,
        photos,
      });
    } catch (err) {
      console.error('Error fetching vendor details:', err);
      res.status(500).json({ error: 'Failed to load vendor details.' });
    }
  });

  // GET /api/vendors/:id/reviews
  router.get('/:id/reviews', (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: 'Invalid vendor ID.' });
      }

      const vendorExists = db.prepare('SELECT id FROM vendors WHERE id = ?').get(id);
      if (!vendorExists) {
        return res.status(404).json({ error: 'Vendor not found.' });
      }

      const reviews = db
        .prepare('SELECT * FROM hygiene_reviews WHERE vendor_id = ? ORDER BY datetime(created_at) DESC, id DESC')
        .all(id);

      res.json({ count: reviews.length, reviews });
    } catch (err) {
      console.error('Error fetching reviews:', err);
      res.status(500).json({ error: 'Failed to load vendor reviews.' });
    }
  });

  // POST /api/vendors/:id/reviews
  router.post(
    '/:id/reviews',
    (req, res, next) => {
      uploadStallPhoto.single('photo')(req, res, (err) => {
        if (err) {
          return res.status(400).json({ error: err.message || 'Invalid image upload.' });
        }
        next();
      });
    },
    (req: Request, res: Response) => {
      try {
        const vendorId = Number(req.params.id);
        if (!Number.isInteger(vendorId) || vendorId <= 0) {
          return res.status(400).json({ error: 'Invalid vendor ID.' });
        }

        const vendorRow = db.prepare('SELECT * FROM vendors WHERE id = ?').get(vendorId) as VendorRow | undefined;
        if (!vendorRow) {
          return res.status(404).json({ error: 'Vendor not found.' });
        }

        const water = parseRating(req.body.water_cleanliness);
        const covered = parseRating(req.body.covered_food);
        const gloves = parseRating(req.body.glove_usage);
        const surroundings = parseRating(req.body.surroundings);

        if (!water || !covered || !gloves || !surroundings) {
          return res.status(400).json({
            error:
              'All four hygiene factors (water cleanliness, covered food, glove usage, surroundings) must be whole numbers between 1 and 5.',
          });
        }

        const reviewerName = sanitizeText(req.body.reviewer_name, 60) || 'Community Diner';
        const observation = sanitizeText(req.body.observation, 600);
        const photoUrl = req.file ? `/uploads/${req.file.filename}` : '';
        const createdAt = new Date().toISOString();

        const info = db
          .prepare(
            `INSERT INTO hygiene_reviews (
              vendor_id, reviewer_name, water_cleanliness, glove_usage,
              covered_food, surroundings, observation, photo, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
          .run(vendorId, reviewerName, water, gloves, covered, surroundings, observation, photoUrl, createdAt);

        if (photoUrl) {
          db.prepare('INSERT INTO vendor_photos (vendor_id, photo_url, caption, created_at) VALUES (?, ?, ?, ?)').run(
            vendorId,
            photoUrl,
            observation ? observation.slice(0, 80) : `Submitted by ${reviewerName}`,
            createdAt
          );
        }

        const reviewScore = calculateWeightedHygieneScore({
          water_cleanliness: water,
          covered_food: covered,
          glove_usage: gloves,
          surroundings,
        });

        const updatedVendor = enrichVendor(db, vendorRow);

        res.status(201).json({
          message: 'Hygiene review recorded and vendor score updated.',
          review: {
            id: Number(info.lastInsertRowid),
            vendor_id: vendorId,
            reviewer_name: reviewerName,
            water_cleanliness: water,
            glove_usage: gloves,
            covered_food: covered,
            surroundings,
            observation,
            photo: photoUrl,
            created_at: createdAt,
            review_score: reviewScore,
          },
          vendor: updatedVendor,
        });
      } catch (err) {
        console.error('Error submitting hygiene review:', err);
        res.status(500).json({ error: 'Unable to save hygiene review.' });
      }
    }
  );

  // PATCH /api/vendors/:id/availability
  router.patch('/:id/availability', (req: Request, res: Response) => {
    try {
      const vendorId = Number(req.params.id);
      if (!Number.isInteger(vendorId) || vendorId <= 0) {
        return res.status(400).json({ error: 'Invalid vendor ID.' });
      }

      const vendorRow = db.prepare('SELECT * FROM vendors WHERE id = ?').get(vendorId) as VendorRow | undefined;
      if (!vendorRow) {
        return res.status(404).json({ error: 'Vendor not found.' });
      }

      const { availability_status, landmark, latitude, longitude } = req.body;
      if (!isValidAvailabilityStatus(availability_status)) {
        return res.status(400).json({ error: 'Status must be Open, Closed, or Unknown.' });
      }

      const updatedAt = new Date().toISOString();
      let newLandmark = vendorRow.landmark;
      let newLat = vendorRow.latitude;
      let newLng = vendorRow.longitude;

      if (vendorRow.is_pushcart === 1) {
        if (typeof landmark === 'string' && sanitizeText(landmark, 120)) {
          newLandmark = sanitizeText(landmark, 120);
        }
        const parsedLat = parseCoordinate(latitude, 17.1, 17.7);
        const parsedLng = parseCoordinate(longitude, 78.1, 78.8);
        if (parsedLat !== null && parsedLng !== null) {
          newLat = parsedLat;
          newLng = parsedLng;
        }
      }

      db.prepare(
        `UPDATE vendors
         SET availability_status = ?, availability_updated_at = ?, landmark = ?, latitude = ?, longitude = ?
         WHERE id = ?`
      ).run(availability_status, updatedAt, newLandmark, newLat, newLng, vendorId);

      const refreshed = db.prepare('SELECT * FROM vendors WHERE id = ?').get(vendorId) as VendorRow;
      res.json({
        message: 'Vendor availability updated.',
        vendor: enrichVendor(db, refreshed),
      });
    } catch (err) {
      console.error('Error updating availability:', err);
      res.status(500).json({ error: 'Unable to update vendor availability.' });
    }
  });

  // POST /api/vendors/:id/photos
  router.post(
    '/:id/photos',
    (req, res, next) => {
      uploadStallPhoto.single('photo')(req, res, (err) => {
        if (err) {
          return res.status(400).json({ error: err.message || 'Invalid image upload.' });
        }
        next();
      });
    },
    (req: Request, res: Response) => {
      try {
        const vendorId = Number(req.params.id);
        if (!Number.isInteger(vendorId) || vendorId <= 0) {
          return res.status(400).json({ error: 'Invalid vendor ID.' });
        }

        const vendorExists = db.prepare('SELECT id FROM vendors WHERE id = ?').get(vendorId);
        if (!vendorExists) {
          return res.status(404).json({ error: 'Vendor not found.' });
        }

        if (!req.file) {
          return res.status(400).json({ error: 'Please select a JPG, PNG, or WebP photo to upload.' });
        }

        const photoUrl = `/uploads/${req.file.filename}`;
        const caption = sanitizeText(req.body.caption, 120) || 'Community stall inspection photo';
        const createdAt = new Date().toISOString();

        const info = db
          .prepare('INSERT INTO vendor_photos (vendor_id, photo_url, caption, created_at) VALUES (?, ?, ?, ?)')
          .run(vendorId, photoUrl, caption, createdAt);

        res.status(201).json({
          message: 'Photo uploaded.',
          photo: {
            id: Number(info.lastInsertRowid),
            vendor_id: vendorId,
            photo_url: photoUrl,
            caption,
            created_at: createdAt,
          },
        });
      } catch (err) {
        console.error('Error uploading photo:', err);
        res.status(500).json({ error: 'Unable to upload photo.' });
      }
    }
  );

  return router;
}
