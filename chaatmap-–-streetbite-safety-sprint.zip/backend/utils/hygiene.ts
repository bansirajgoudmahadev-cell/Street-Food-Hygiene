export interface HygieneFactors {
  water_cleanliness: number;
  covered_food: number;
  glove_usage: number;
  surroundings: number;
}

export interface HygieneSummary extends HygieneFactors {
  hygiene_score: number;
  review_count: number;
}

export const HYGIENE_WEIGHTS = {
  water_cleanliness: 0.40,
  covered_food: 0.25,
  glove_usage: 0.20,
  surroundings: 0.15,
} as const;

/**
 * Computes the weighted Hygiene Trust Score for a single review or averaged factors:
 * Hygiene Score = (0.40 * Water) + (0.25 * Covered Food) + (0.20 * Gloves) + (0.15 * Surroundings)
 */
export function calculateWeightedHygieneScore(factors: HygieneFactors): number {
  const score =
    HYGIENE_WEIGHTS.water_cleanliness * factors.water_cleanliness +
    HYGIENE_WEIGHTS.covered_food * factors.covered_food +
    HYGIENE_WEIGHTS.glove_usage * factors.glove_usage +
    HYGIENE_WEIGHTS.surroundings * factors.surroundings;

  return Math.round(score * 100) / 100;
}

export function calculateVendorHygieneSummary(reviews: HygieneFactors[]): HygieneSummary {
  if (!reviews || reviews.length === 0) {
    return {
      water_cleanliness: 0,
      covered_food: 0,
      glove_usage: 0,
      surroundings: 0,
      hygiene_score: 0,
      review_count: 0,
    };
  }

  const count = reviews.length;
  const totals = reviews.reduce(
    (acc, r) => ({
      water_cleanliness: acc.water_cleanliness + Number(r.water_cleanliness),
      covered_food: acc.covered_food + Number(r.covered_food),
      glove_usage: acc.glove_usage + Number(r.glove_usage),
      surroundings: acc.surroundings + Number(r.surroundings),
    }),
    { water_cleanliness: 0, covered_food: 0, glove_usage: 0, surroundings: 0 }
  );

  const averages: HygieneFactors = {
    water_cleanliness: Math.round((totals.water_cleanliness / count) * 100) / 100,
    covered_food: Math.round((totals.covered_food / count) * 100) / 100,
    glove_usage: Math.round((totals.glove_usage / count) * 100) / 100,
    surroundings: Math.round((totals.surroundings / count) * 100) / 100,
  };

  return {
    ...averages,
    hygiene_score: calculateWeightedHygieneScore(averages),
    review_count: count,
  };
}
