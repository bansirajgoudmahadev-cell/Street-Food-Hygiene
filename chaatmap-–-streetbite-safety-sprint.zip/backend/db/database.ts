import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

let dbInstance: Database.Database | null = null;

export function getDbPath(): string {
  return path.resolve(process.cwd(), process.env.DB_PATH || './backend/data/chaatmap.db');
}

export function getDatabase(): Database.Database {
  if (dbInstance) return dbInstance;

  const dbPath = getDbPath();
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  initializeSchema(db);
  dbInstance = db;
  return db;
}

export function initializeSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS vendors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      locality TEXT NOT NULL,
      address TEXT NOT NULL,
      landmark TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      cuisine TEXT NOT NULL,
      price_min INTEGER NOT NULL CHECK (price_min >= 0),
      price_max INTEGER NOT NULL CHECK (price_max >= price_min),
      opening_time TEXT NOT NULL,
      closing_time TEXT NOT NULL,
      image TEXT NOT NULL,
      fssai_verified INTEGER NOT NULL DEFAULT 0 CHECK (fssai_verified IN (0, 1)),
      availability_status TEXT NOT NULL DEFAULT 'Unknown' CHECK (availability_status IN ('Open', 'Closed', 'Unknown')),
      availability_updated_at TEXT NOT NULL,
      is_pushcart INTEGER NOT NULL DEFAULT 0 CHECK (is_pushcart IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS dishes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vendor_id INTEGER NOT NULL,
      dish_name TEXT NOT NULL,
      price INTEGER NOT NULL CHECK (price > 0),
      description TEXT NOT NULL,
      FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS hygiene_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vendor_id INTEGER NOT NULL,
      reviewer_name TEXT NOT NULL DEFAULT 'Community Diner',
      water_cleanliness INTEGER NOT NULL CHECK (water_cleanliness BETWEEN 1 AND 5),
      glove_usage INTEGER NOT NULL CHECK (glove_usage BETWEEN 1 AND 5),
      covered_food INTEGER NOT NULL CHECK (covered_food BETWEEN 1 AND 5),
      surroundings INTEGER NOT NULL CHECK (surroundings BETWEEN 1 AND 5),
      observation TEXT DEFAULT '',
      photo TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS vendor_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vendor_id INTEGER NOT NULL,
      photo_url TEXT NOT NULL,
      caption TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS food_trails (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      locality TEXT NOT NULL,
      description TEXT NOT NULL,
      estimated_duration TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS food_trail_vendors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      trail_id INTEGER NOT NULL,
      vendor_id INTEGER NOT NULL,
      sequence_order INTEGER NOT NULL CHECK (sequence_order >= 1),
      FOREIGN KEY (trail_id) REFERENCES food_trails(id) ON DELETE CASCADE,
      FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
      UNIQUE (trail_id, vendor_id)
    );

    CREATE INDEX IF NOT EXISTS idx_vendors_locality ON vendors(locality);
    CREATE INDEX IF NOT EXISTS idx_vendors_cuisine ON vendors(cuisine);
    CREATE INDEX IF NOT EXISTS idx_dishes_vendor_id ON dishes(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_reviews_vendor_id ON hygiene_reviews(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_trail_vendors_trail_id ON food_trail_vendors(trail_id);
  `);
}
