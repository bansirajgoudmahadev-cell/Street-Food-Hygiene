import 'dotenv/config';
import { getDatabase } from './database';
import { seedDatabase } from './seed';

const db = getDatabase();
const summary = seedDatabase(db);
console.log(
  `ChaatMap SQLite initialized: ${summary.vendors} vendors, ${summary.reviews} hygiene reviews, ${summary.trails} food trails.`
);
