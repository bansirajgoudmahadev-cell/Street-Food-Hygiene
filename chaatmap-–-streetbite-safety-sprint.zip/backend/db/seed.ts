import Database from 'better-sqlite3';

const IMAGES = {
  hero: '/src/assets/images/hero_hyderabad_chaat_1795195067332.jpg',
  paniPuri: '/src/assets/images/food_pani_puri_1795195067249.jpg',
  dosa: '/src/assets/images/food_masala_dosa_1795195066358.jpg',
  pavBhaji: '/src/assets/images/food_pav_bhaji_1795195066835.jpg',
  momos: '/src/assets/images/food_steamed_momos_1795195066452.jpg',
  mirchiBajji: '/src/assets/images/food_mirchi_bajji_1795195067283.jpg',
  chaat: '/src/assets/images/food_chaat_platter_1795195065896.jpg',
  cart: '/src/assets/images/vendor_clean_cart_1795195067268.jpg',
};

interface SeedVendor {
  name: string;
  description: string;
  locality: string;
  address: string;
  landmark: string;
  latitude: number;
  longitude: number;
  cuisine: string;
  price_min: number;
  price_max: number;
  opening_time: string;
  closing_time: string;
  image: string;
  fssai_verified: number;
  availability_status: 'Open' | 'Closed' | 'Unknown';
  availability_updated_at: string;
  is_pushcart: number;
  dishes: { dish_name: string; price: number; description: string }[];
  reviews: {
    reviewer_name: string;
    water_cleanliness: number;
    glove_usage: number;
    covered_food: number;
    surroundings: number;
    observation: string;
    created_at: string;
  }[];
}

const SEED_VENDORS: SeedVendor[] = [
  {
    name: 'Mahalaxmi Chaat Center',
    description:
      'Long-standing Sindhi Colony stall known for chilled RO-water mint pani puri, covered stainless steel garnish trays, and crisp ragda patties.',
    locality: 'Sindhi Colony',
    address: 'Lane 2, PG Road, Sindhi Colony, Secunderabad',
    landmark: 'Opposite Vasavi Bhavan Gate',
    latitude: 17.4418,
    longitude: 78.4814,
    cuisine: 'Pani Puri',
    price_min: 40,
    price_max: 90,
    opening_time: '16:30',
    closing_time: '22:30',
    image: IMAGES.hero,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:45:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Mint & Tamarind Pani Puri (8 pcs)', price: 40, description: 'Crisp semolina puris served with chilled RO-filtered mint water.' },
      { dish_name: 'Dahi Papdi Chaat', price: 70, description: 'Chilled whisked curd over crisp papdi, chickpeas, and pomegranate.' },
      { dish_name: 'Ragda Patties', price: 80, description: 'Pan-seared potato patties topped with spiced white pea curry.' },
    ],
    reviews: [
      { reviewer_name: 'Ananya Reddy', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Visible Bisleri/RO dispenser for pani, glass sneeze shield covers all puris, staff wears disposable gloves.', created_at: '2026-11-18T13:20:00.000Z' },
      { reviewer_name: 'Karthik Rao', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Counters wiped frequently with clean cloth. Dustbins kept tucked aside.', created_at: '2026-11-16T14:10:00.000Z' },
      { reviewer_name: 'Meera Nair', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Very tidy steel station even during peak evening rush.', created_at: '2026-11-14T15:00:00.000Z' },
      { reviewer_name: 'Siddharth Varma', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Zero bare-hand handling of puris or filling.', created_at: '2026-11-10T12:40:00.000Z' },
    ],
  },
  {
    name: 'Popular Pani Puri Stall',
    description:
      'Evening pushcart near Madhapur Metro offering spicy pudina and sweet dates pani puri with packaged mineral water.',
    locality: 'Madhapur',
    address: '100 Feet Road Junction, Madhapur, Hyderabad',
    landmark: 'Beside Madhapur Metro Pillar C1758',
    latitude: 17.4488,
    longitude: 78.3912,
    cuisine: 'Pani Puri',
    price_min: 30,
    price_max: 70,
    opening_time: '17:00',
    closing_time: '22:00',
    image: IMAGES.paniPuri,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:10:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Classic Golgappa Plate', price: 30, description: 'Six crisp puris with warm spiced ragda and garlic-mint water.' },
      { dish_name: 'Sev Puri', price: 60, description: 'Flat puris layered with diced potato, raw mango, and fine nylon sev.' },
    ],
    reviews: [
      { reviewer_name: 'Rohan Deshmukh', water_cleanliness: 5, glove_usage: 4, covered_food: 4, surroundings: 4, observation: 'Uses sealed 20L RO water cans and steel ladles for serving pani.', created_at: '2026-11-17T14:00:00.000Z' },
      { reviewer_name: 'Priya Menon', water_cleanliness: 4, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Acrylic lid kept closed between orders. Clean paper plates.', created_at: '2026-11-12T13:30:00.000Z' },
      { reviewer_name: 'Vikram Joshi', water_cleanliness: 5, glove_usage: 4, covered_food: 4, surroundings: 4, observation: 'Good water hygiene, slight crowding near the footpath.', created_at: '2026-11-08T14:45:00.000Z' },
    ],
  },
  {
    name: 'Sri Sai Dosa Point',
    description:
      'Early-morning to late-night tiffin cart famous for ghee karam masala dosa and piping hot sambar served on banana-leaf lined steel plates.',
    locality: 'Ameerpet',
    address: 'Mythri Vanam Cross Road, Ameerpet, Hyderabad',
    landmark: 'Next to Aditya Enclave Entrance',
    latitude: 17.4375,
    longitude: 78.4482,
    cuisine: 'Dosa',
    price_min: 45,
    price_max: 110,
    opening_time: '07:00',
    closing_time: '22:00',
    image: IMAGES.dosa,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T06:30:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Ghee Karam Masala Dosa', price: 75, description: 'Crisp fermented crepe brushed with roasted red chili garlic paste and ghee.' },
      { dish_name: 'Butter Cheese Dosa', price: 110, description: 'Golden dosa filled with potato masala and grated cheddar.' },
      { dish_name: 'Pesarattu Upma', price: 65, description: 'Green moong crepe stuffed with ginger-spiced semolina upma.' },
    ],
    reviews: [
      { reviewer_name: 'Deepak Kulkarni', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Chutney containers kept covered in insulated steel pots; clean drinking water filter on cart.', created_at: '2026-11-19T04:30:00.000Z' },
      { reviewer_name: 'Sravani Goud', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Fresh banana leaf liners used on every plate, no re-used disposables.', created_at: '2026-11-15T05:15:00.000Z' },
      { reviewer_name: 'Nikhil Sharma', water_cleanliness: 4, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Tawa scraped clean between batches and fresh batter kept chilled.', created_at: '2026-11-09T06:00:00.000Z' },
    ],
  },
  {
    name: 'Old City Chaat Corner',
    description:
      'Bustling heritage-lane chaat stall serving smoky aloo tikki, palak patta chaat, and sweet-sour imli pani.',
    locality: 'Old City',
    address: 'Pathergatti Main Road, Near Charminar, Hyderabad',
    landmark: '50m East of Charminar Bus Bay',
    latitude: 17.3618,
    longitude: 78.4754,
    cuisine: 'Chaat',
    price_min: 40,
    price_max: 100,
    opening_time: '15:30',
    closing_time: '23:00',
    image: IMAGES.chaat,
    fssai_verified: 0,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T07:50:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Crisp Aloo Tikki Chaat', price: 60, description: 'Ghee-griddled potato medallions with spiced chickpeas and yogurt.' },
      { dish_name: 'Palak Patta Chaat', price: 80, description: 'Crispy spinach fritters drizzled with tamarind glaze and sev.' },
    ],
    reviews: [
      { reviewer_name: 'Farhan Ahmed', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 3, observation: 'Chutneys covered with steel lids, though street corner gets busy after 7 PM.', created_at: '2026-11-17T15:00:00.000Z' },
      { reviewer_name: 'Zoya Begum', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 4, observation: 'Food served piping hot from tawa; filtered water used for chutneys.', created_at: '2026-11-11T14:20:00.000Z' },
    ],
  },
  {
    name: 'Hyderabad Momos Junction',
    description:
      'Steamed and pan-tossed Himalayan-style momos with roasted tomato-garlic chili dip and strict food-grade glove handling.',
    locality: 'Sindhi Colony',
    address: '4th Cross, Sindhi Colony, Secunderabad',
    landmark: 'Near Paradise Metro Walkway',
    latitude: 17.4426,
    longitude: 78.4829,
    cuisine: 'Momos',
    price_min: 60,
    price_max: 120,
    opening_time: '16:00',
    closing_time: '22:45',
    image: IMAGES.momos,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:30:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Steamed Paneer Herb Momos (8 pcs)', price: 90, description: 'Thin-wrapped dumplings filled with crumbled cottage cheese and scallions.' },
      { dish_name: 'Veg Darjeeling Momos (8 pcs)', price: 70, description: 'Cabbage, carrot, and ginger steamed dumplings with fiery red chutney.' },
      { dish_name: 'Kurkure Veg Momos', price: 120, description: 'Crisp crumb-coated momos served with herb mayonnaise.' },
    ],
    reviews: [
      { reviewer_name: 'Tenzing Lama', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Steamers sealed cleanly, tongs and gloves used for every plate.', created_at: '2026-11-18T14:15:00.000Z' },
      { reviewer_name: 'Aisha Kapoor', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Spotless stainless counter and covered sauce bottles.', created_at: '2026-11-13T13:50:00.000Z' },
      { reviewer_name: 'Harish Babu', water_cleanliness: 4, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Hairnets worn by both cooks; very clean surroundings.', created_at: '2026-11-07T15:10:00.000Z' },
    ],
  },
  {
    name: 'Bombay Express Pav Bhaji',
    description:
      'Sizzling butter pav bhaji prepared on a gleaming cast-iron tawa using fresh market vegetables and branded dairy butter.',
    locality: 'Sindhi Colony',
    address: 'Main Food Street, Sindhi Colony, Secunderabad',
    landmark: 'Opposite Ratnadeep Supermarket',
    latitude: 17.4409,
    longitude: 78.4803,
    cuisine: 'Pav Bhaji',
    price_min: 70,
    price_max: 120,
    opening_time: '17:00',
    closing_time: '23:15',
    image: IMAGES.pavBhaji,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:05:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Butter Pav Bhaji (2 Pav)', price: 80, description: 'Slow-mashed spiced vegetables topped with fresh butter and onions.' },
      { dish_name: 'Cheese Masala Pav Bhaji', price: 115, description: 'Loaded with grated cheese and garlic-tossed toasted pav.' },
    ],
    reviews: [
      { reviewer_name: 'Sneha Patel', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Chopped onions and lemons stored in covered steel containers.', created_at: '2026-11-18T15:40:00.000Z' },
      { reviewer_name: 'Arjun Verma', water_cleanliness: 4, glove_usage: 5, covered_food: 4, surroundings: 5, observation: 'Chef wears apron and cap; tawa area is kept tidy.', created_at: '2026-11-14T14:20:00.000Z' },
      { reviewer_name: 'Kavya Iyer', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'RO water used for washing vegetables and boiling bhaji.', created_at: '2026-11-05T16:00:00.000Z' },
    ],
  },
  {
    name: 'Deccan Mirchi Bajji Hut',
    description:
      'Authentic Hyderabadi stuffed mirchi bajji split and topped with roasted peanuts, raw onions, coriander, and fresh lime.',
    locality: 'Old City',
    address: 'Laad Bazaar Approach Road, Old City, Hyderabad',
    landmark: 'Near Mecca Masjid Archway',
    latitude: 17.3609,
    longitude: 78.4731,
    cuisine: 'Mirchi Bajji',
    price_min: 30,
    price_max: 70,
    opening_time: '15:00',
    closing_time: '21:30',
    image: IMAGES.mirchiBajji,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T07:20:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Cut Mirchi Bajji (3 pcs)', price: 40, description: 'Crispy chili fritters sliced and tossed with onion, peanuts, and chaat masala.' },
      { dish_name: 'Aloo Bonda & Punugulu Combo', price: 50, description: 'Golden lentil fritters with ginger-peanut chutney.' },
    ],
    reviews: [
      { reviewer_name: 'Imran Khan', water_cleanliness: 4, glove_usage: 4, covered_food: 4, surroundings: 4, observation: 'Fresh sunflower oil changed daily; chutneys stored in covered steel vessels.', created_at: '2026-11-16T12:30:00.000Z' },
      { reviewer_name: 'Neha Singh', water_cleanliness: 4, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Glass cabinet keeps fried bajjis protected from dust.', created_at: '2026-11-10T13:15:00.000Z' },
    ],
  },
  {
    name: 'CyberTowers Clean Tiffins',
    description:
      'Sanitized morning-and-evening South Indian tiffin van catering to HITEC City professionals with closed glass counters.',
    locality: 'Madhapur',
    address: 'Cyber Towers Junction, Madhapur, Hyderabad',
    landmark: 'Opposite Shilparamam Craft Village Gate',
    latitude: 17.4508,
    longitude: 78.3812,
    cuisine: 'Dosa',
    price_min: 45,
    price_max: 110,
    opening_time: '07:30',
    closing_time: '21:30',
    image: IMAGES.dosa,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:00:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Ragi Onion Dosa', price: 70, description: 'Nutritious finger-millet dosa topped with caramelized onions and curry leaves.' },
      { dish_name: 'Button Idli Sambar Bowl', price: 50, description: 'Mini steamed rice cakes soaked in drumstick sambar and pure ghee.' },
    ],
    reviews: [
      { reviewer_name: 'Suresh Pillai', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Best roadside dosa hygiene near HITEC; full gloves, hairnet, and RO water jar.', created_at: '2026-11-19T05:00:00.000Z' },
      { reviewer_name: 'Divya Krishnan', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Clean steel utensils and covered chutney dispensers.', created_at: '2026-11-15T04:45:00.000Z' },
      { reviewer_name: 'Manish Tiwari', water_cleanliness: 5, glove_usage: 5, covered_food: 4, surroundings: 5, observation: 'Pavement around the cart is swept clean.', created_at: '2026-11-09T06:20:00.000Z' },
    ],
  },
  {
    name: 'Royal Hyderabad Snacks Cart',
    description:
      'Well-lit pushcart featuring acrylic display cases, mounted RO water dispenser, and crispy evening mirchi bajji & samosas.',
    locality: 'Banjara Hills',
    address: 'Road No. 12, Banjara Hills, Hyderabad',
    landmark: 'Near KBR Park Walking Track Gate 2',
    latitude: 17.4134,
    longitude: 78.4272,
    cuisine: 'Mirchi Bajji',
    price_min: 35,
    price_max: 85,
    opening_time: '16:00',
    closing_time: '22:00',
    image: IMAGES.cart,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:50:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Stuffed Mirchi Bajji Platter', price: 45, description: 'Tamarind-stuffed chili fritters with fresh onion relish.' },
      { dish_name: 'Onion Samosa (4 pcs)', price: 40, description: 'Flaky triangular pastry filled with spiced caramelized onions.' },
    ],
    reviews: [
      { reviewer_name: 'Lakshmi Prasad', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Mounted Aqua purifier right on the cart and crystal-clear display glass.', created_at: '2026-11-18T12:15:00.000Z' },
      { reviewer_name: 'Ritesh Agarwal', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Covered waste bin tucked beneath the cart; zero littering.', created_at: '2026-11-14T13:10:00.000Z' },
      { reviewer_name: 'Pooja Bhatia', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Consistent gloves and apron usage.', created_at: '2026-11-06T12:45:00.000Z' },
    ],
  },
  {
    name: 'Durgam Cheruvu Pav & Chaat',
    description:
      'Lakeside evening stall serving hot butter pav bhaji and Mumbai-style bhel puri near the Durgam Cheruvu promenade.',
    locality: 'Madhapur',
    address: 'Inorbit Mall Road, Madhapur, Hyderabad',
    landmark: 'Opposite Durgam Cheruvu Cable Bridge Viewpoint',
    latitude: 17.4314,
    longitude: 78.3879,
    cuisine: 'Pav Bhaji',
    price_min: 60,
    price_max: 120,
    opening_time: '17:00',
    closing_time: '23:00',
    image: IMAGES.pavBhaji,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T07:45:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Special Amul Pav Bhaji', price: 95, description: 'Rich tomato-potato bhaji served with two buttered buns.' },
      { dish_name: 'Dry Sukha Bhel', price: 60, description: 'Puffed rice tossed with roasted peanuts, garlic chutney, and crisp sev.' },
    ],
    reviews: [
      { reviewer_name: 'Gaurav Mehta', water_cleanliness: 4, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'Fresh ingredients stored in sealed transparent tubs.', created_at: '2026-11-17T15:20:00.000Z' },
      { reviewer_name: 'Shruti Sen', water_cleanliness: 5, glove_usage: 4, covered_food: 4, surroundings: 4, observation: 'Prompt service, clean disposable wooden spoons.', created_at: '2026-11-11T14:50:00.000Z' },
      { reviewer_name: 'Raghavendra K', water_cleanliness: 4, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Lakeside seating kept neat with separate wet and dry bins.', created_at: '2026-11-05T15:10:00.000Z' },
    ],
  },
  {
    name: 'Tank Bund Crispy Bajji Van',
    description:
      'Lakeside evening snack van popular with walkers for hot punugulu, mirchi bajji, and ginger chai.',
    locality: 'Tank Bund',
    address: 'Necklace Road / Tank Bund Promenade, Hyderabad',
    landmark: 'Near Jalavihar Water Park Entrance',
    latitude: 17.4246,
    longitude: 78.4722,
    cuisine: 'Mirchi Bajji',
    price_min: 30,
    price_max: 80,
    opening_time: '16:30',
    closing_time: '22:00',
    image: IMAGES.mirchiBajji,
    fssai_verified: 0,
    availability_status: 'Closed',
    availability_updated_at: '2026-11-20T05:15:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Pepper Punugulu (10 pcs)', price: 35, description: 'Crisp urad-dal batter bites with peanut-coconut chutney.' },
      { dish_name: 'Mirchi Bajji Plate', price: 45, description: 'Two large stuffed green chili fritters with onion-lemon topping.' },
    ],
    reviews: [
      { reviewer_name: 'Venkat Rao', water_cleanliness: 3, glove_usage: 3, covered_food: 4, surroundings: 3, observation: 'Hot food fried fresh, but lacks gloves when handing paper plates.', created_at: '2026-11-15T14:00:00.000Z' },
      { reviewer_name: 'Swathi K', water_cleanliness: 4, glove_usage: 3, covered_food: 3, surroundings: 4, observation: 'Reasonably clean van area; chutneys covered during wind.', created_at: '2026-11-08T13:30:00.000Z' },
    ],
  },
  {
    name: 'KPHB Everest Momos Express',
    description:
      'Busy student-favorite momo stall near KPHB Metro using multi-tier stainless steel steamers and sealed chili dips.',
    locality: 'Kukatpally',
    address: 'KPHB Colony Phase 1, Kukatpally, Hyderabad',
    landmark: '200m from KPHB Metro Exit B',
    latitude: 17.4939,
    longitude: 78.4018,
    cuisine: 'Momos',
    price_min: 50,
    price_max: 110,
    opening_time: '16:00',
    closing_time: '22:30',
    image: IMAGES.momos,
    fssai_verified: 0,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:15:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Classic Veg Steamed Momos', price: 60, description: 'Eight freshly steamed vegetable dumplings with tomato-garlic chutney.' },
      { dish_name: 'Schezwan Tossed Momos', price: 100, description: 'Wok-tossed momos with bell peppers and spring onions.' },
    ],
    reviews: [
      { reviewer_name: 'Chaitanya V', water_cleanliness: 4, glove_usage: 4, covered_food: 4, surroundings: 3, observation: 'Tongs used for serving momos, though footpath gets crowded at 8 PM.', created_at: '2026-11-17T15:10:00.000Z' },
      { reviewer_name: 'Pallavi M', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 4, observation: 'Steamer stays covered and steaming hot.', created_at: '2026-11-12T14:40:00.000Z' },
    ],
  },
  {
    name: 'Secunderabad Sardarji Chaat',
    description:
      'Clean family-run Sindhi Colony cart celebrated for crisp samosa chole chaat, dahi bhalla, and RO-filtered tamarind water.',
    locality: 'Sindhi Colony',
    address: '3rd Lane, Sindhi Colony, Secunderabad',
    landmark: 'Beside St. Ann’s School Wall',
    latitude: 17.4431,
    longitude: 78.4796,
    cuisine: 'Chaat',
    price_min: 50,
    price_max: 110,
    opening_time: '16:00',
    closing_time: '22:30',
    image: IMAGES.chaat,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:35:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Dahi Bhalla Papdi', price: 80, description: 'Soft lentil dumplings soaked in creamy yogurt and sweet tamarind.' },
      { dish_name: 'Samosa Chole Chaat', price: 65, description: 'Crushed Punjabi samosa topped with spiced Kabuli chana and mint.' },
    ],
    reviews: [
      { reviewer_name: 'Jaspreet Kaur', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Curd kept chilled in insulated steel icebox; clean spoons and bowls.', created_at: '2026-11-18T13:55:00.000Z' },
      { reviewer_name: 'Mahesh Reddy', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Very tidy lane setup with proper waste segregation bin.', created_at: '2026-11-13T14:30:00.000Z' },
      { reviewer_name: 'Nandini S', water_cleanliness: 4, glove_usage: 5, covered_food: 5, surroundings: 5, observation: 'Both staff members wear caps and gloves consistently.', created_at: '2026-11-06T13:05:00.000Z' },
    ],
  },
  {
    name: 'Charminar Nawab Pani Puri',
    description:
      'Traditional Old City golgappa cart serving tangy khatta-meetha tamarind water and warm spiced peas.',
    locality: 'Old City',
    address: 'Charkaman Arch Road, Old City, Hyderabad',
    landmark: 'Near Charkaman Fountain',
    latitude: 17.3627,
    longitude: 78.4743,
    cuisine: 'Pani Puri',
    price_min: 30,
    price_max: 60,
    opening_time: '16:00',
    closing_time: '22:30',
    image: IMAGES.paniPuri,
    fssai_verified: 0,
    availability_status: 'Unknown',
    availability_updated_at: '2026-11-18T14:00:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Matar Pani Puri (7 pcs)', price: 30, description: 'Crisp wheat puris filled with spiced yellow peas and black-salt pani.' },
      { dish_name: 'Bhel Chaat Cup', price: 50, description: 'Quick puffed rice and crunchy papdi mix with raw onions.' },
    ],
    reviews: [
      { reviewer_name: 'Sameer Ali', water_cleanliness: 3, glove_usage: 2, covered_food: 3, surroundings: 3, observation: 'Tasty tamarind water, though vendor serves puris bare-handed.', created_at: '2026-11-14T15:00:00.000Z' },
      { reviewer_name: 'Fatima Noor', water_cleanliness: 3, glove_usage: 3, covered_food: 3, surroundings: 3, observation: 'Puris kept in a covered plastic tub, surroundings can get dusty.', created_at: '2026-11-07T14:15:00.000Z' },
    ],
  },
  {
    name: 'Madhapur Spice Momos Hub',
    description:
      'Evening momos and crispy spring-roll cart near Durgam Cheruvu Metro serving freshly steamed batches every 15 minutes.',
    locality: 'Madhapur',
    address: 'Ayyappa Society Main Road, Madhapur, Hyderabad',
    landmark: 'Opposite Meridian School Lane',
    latitude: 17.4461,
    longitude: 78.3936,
    cuisine: 'Momos',
    price_min: 60,
    price_max: 120,
    opening_time: '16:30',
    closing_time: '23:00',
    image: IMAGES.momos,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:20:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Steamed Corn & Cheese Momos', price: 100, description: 'Sweet corn and mozzarella stuffed momos with red chili dip.' },
      { dish_name: 'Classic Veg Momos', price: 65, description: 'Lightly spiced vegetable momos steamed to order.' },
    ],
    reviews: [
      { reviewer_name: 'Aditya Jain', water_cleanliness: 4, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Tongs used for plating and clean disposable boxes for takeaway.', created_at: '2026-11-16T15:30:00.000Z' },
      { reviewer_name: 'Ritika Bose', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 4, observation: 'RO water used in steamer and chutney prep.', created_at: '2026-11-10T14:50:00.000Z' },
    ],
  },
  {
    name: 'Dilsukhnagar Tiffin & Dosa Corner',
    description:
      'Popular neighborhood tiffin counter serving crisp butter masala dosa, Mysore bonda, and steaming sambar.',
    locality: 'Dilsukhnagar',
    address: 'Chaitanyapuri Main Road, Dilsukhnagar, Hyderabad',
    landmark: 'Near Dilsukhnagar Metro Pillar A1540',
    latitude: 17.3688,
    longitude: 78.5247,
    cuisine: 'Dosa',
    price_min: 40,
    price_max: 95,
    opening_time: '06:45',
    closing_time: '21:30',
    image: IMAGES.dosa,
    fssai_verified: 0,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T06:00:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Mysore Masala Dosa', price: 65, description: 'Spicy red chutney spread dosa with seasoned potato masala.' },
      { dish_name: 'Set Dosa (3 pcs)', price: 55, description: 'Soft spongy dosas paired with vegetable sagu and coconut chutney.' },
    ],
    reviews: [
      { reviewer_name: 'Srinivas Chary', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 4, observation: 'Hot tawa items are hygienic; chutneys kept covered.', created_at: '2026-11-18T03:30:00.000Z' },
      { reviewer_name: 'Bhavana K', water_cleanliness: 4, glove_usage: 4, covered_food: 4, surroundings: 3, observation: 'Quick turnaround so batter and sambar stay fresh.', created_at: '2026-11-09T04:10:00.000Z' },
    ],
  },
  {
    name: 'Banjara Spice Pav Bhaji',
    description:
      'Evening pushcart near Jubilee Checkpost offering aromatic butter pav bhaji and tawa pulao prepared on clean steel counters.',
    locality: 'Banjara Hills',
    address: 'Road No. 1, Banjara Hills, Hyderabad',
    landmark: 'Outside City Center Lane',
    latitude: 17.4162,
    longitude: 78.4485,
    cuisine: 'Pav Bhaji',
    price_min: 75,
    price_max: 120,
    opening_time: '17:30',
    closing_time: '23:00',
    image: IMAGES.pavBhaji,
    fssai_verified: 1,
    availability_status: 'Closed',
    availability_updated_at: '2026-11-20T04:00:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Jain Butter Pav Bhaji', price: 90, description: 'No-onion, no-garlic spiced vegetable bhaji with toasted pav.' },
      { dish_name: 'Tawa Veg Pulao', price: 100, description: 'Basmati rice tossed on the bhaji tawa with cashews and peas.' },
    ],
    reviews: [
      { reviewer_name: 'Kunal Shah', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Very clean stall with packaged water and covered onion bowls.', created_at: '2026-11-15T16:15:00.000Z' },
      { reviewer_name: 'Rhea Kapoor', water_cleanliness: 4, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Gloves worn while toasting buns and plating.', created_at: '2026-11-08T15:45:00.000Z' },
    ],
  },
  {
    name: 'Laad Bazaar Mirchi & Chai',
    description:
      'Historic Old City corner stall serving crisp stuffed mirchi bajji and Osmania biscuits beside Laad Bazaar.',
    locality: 'Old City',
    address: 'Laad Bazaar Corner, Old City, Hyderabad',
    landmark: 'Opposite Chowmahalla Gate Lane',
    latitude: 17.3596,
    longitude: 78.4721,
    cuisine: 'Mirchi Bajji',
    price_min: 30,
    price_max: 75,
    opening_time: '15:30',
    closing_time: '22:00',
    image: IMAGES.mirchiBajji,
    fssai_verified: 0,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T07:55:00.000Z',
    is_pushcart: 0,
    dishes: [
      { dish_name: 'Hyderabadi Mirchi Bajji', price: 35, description: 'Crisp gram-flour coated green chilies with sesame-tamarind filling.' },
      { dish_name: 'Crispy Onion Pakoda', price: 50, description: 'Spiced sliced onion fritters served with mint chutney.' },
    ],
    reviews: [
      { reviewer_name: 'Tariq Aziz', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 3, observation: 'Oil looks fresh and golden; tongs used to lift bajjis from tray.', created_at: '2026-11-16T13:45:00.000Z' },
      { reviewer_name: 'Ayesha Siddiqui', water_cleanliness: 3, glove_usage: 4, covered_food: 4, surroundings: 3, observation: 'Covered mesh guard over fried snacks.', created_at: '2026-11-06T14:20:00.000Z' },
    ],
  },
  {
    name: 'Sindhi Colony Ghee Dosa Cart',
    description:
      'Evening tiffin cart on PG Road serving crisp benne-style ghee dosa and ginger chutney under bright hygienic LED lighting.',
    locality: 'Sindhi Colony',
    address: 'PG Road Corner, Sindhi Colony, Secunderabad',
    landmark: 'Opposite Syndicate Bank ATM',
    latitude: 17.4412,
    longitude: 78.4822,
    cuisine: 'Dosa',
    price_min: 50,
    price_max: 110,
    opening_time: '17:00',
    closing_time: '22:30',
    image: IMAGES.dosa,
    fssai_verified: 1,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:40:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Benne Masala Dosa', price: 85, description: 'Thick golden butter-roasted dosa with spiced aloo palya.' },
      { dish_name: 'Paper Plain Dosa', price: 55, description: 'Extra-crisp thin dosa served with three fresh chutneys.' },
    ],
    reviews: [
      { reviewer_name: 'Vivek N', water_cleanliness: 5, glove_usage: 4, covered_food: 5, surroundings: 5, observation: 'Chutneys served with long steel ladles from covered canisters.', created_at: '2026-11-18T14:30:00.000Z' },
      { reviewer_name: 'Keerthi Rao', water_cleanliness: 5, glove_usage: 5, covered_food: 5, surroundings: 4, observation: 'Clean apron and cap worn; RO water used for batter.', created_at: '2026-11-12T13:55:00.000Z' },
    ],
  },
  {
    name: 'Ameerpet Metro Chaat Express',
    description:
      'Quick-stop student chaat cart outside Ameerpet Metro offering hygienic sev puri, bhel puri, and dahi samosa.',
    locality: 'Ameerpet',
    address: 'Satyam Theatre Road, Ameerpet, Hyderabad',
    landmark: 'Near Ameerpet Metro Interchange Exit C',
    latitude: 17.4357,
    longitude: 78.4449,
    cuisine: 'Chaat',
    price_min: 35,
    price_max: 85,
    opening_time: '15:30',
    closing_time: '22:00',
    image: IMAGES.chaat,
    fssai_verified: 0,
    availability_status: 'Open',
    availability_updated_at: '2026-11-20T08:02:00.000Z',
    is_pushcart: 1,
    dishes: [
      { dish_name: 'Masala Bhel Puri', price: 45, description: 'Puffed rice, raw mango, coriander, and tamarind drizzle.' },
      { dish_name: 'Dahi Kachori Chaat', price: 65, description: 'Flaky dal kachori topped with yogurt, sev, and mint chutney.' },
    ],
    reviews: [
      { reviewer_name: 'Pranav G', water_cleanliness: 4, glove_usage: 4, covered_food: 4, surroundings: 4, observation: 'Uses disposable gloves and covered garnish boxes.', created_at: '2026-11-17T12:40:00.000Z' },
      { reviewer_name: 'Sindhuja P', water_cleanliness: 4, glove_usage: 3, covered_food: 4, surroundings: 3, observation: 'Clean steel bowls, busy metro sidewalk location.', created_at: '2026-11-09T13:20:00.000Z' },
    ],
  },
];

export function seedDatabase(db: Database.Database): { vendors: number; reviews: number; trails: number } {
  const existing = db.prepare('SELECT COUNT(*) AS count FROM vendors').get() as { count: number };
  if (existing.count > 0) {
    const revCount = (db.prepare('SELECT COUNT(*) AS count FROM hygiene_reviews').get() as { count: number }).count;
    const trailCount = (db.prepare('SELECT COUNT(*) AS count FROM food_trails').get() as { count: number }).count;
    return { vendors: existing.count, reviews: revCount, trails: trailCount };
  }

  const insertVendor = db.prepare(`
    INSERT INTO vendors (
      name, description, locality, address, landmark, latitude, longitude,
      cuisine, price_min, price_max, opening_time, closing_time, image,
      fssai_verified, availability_status, availability_updated_at, is_pushcart
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertDish = db.prepare(`
    INSERT INTO dishes (vendor_id, dish_name, price, description) VALUES (?, ?, ?, ?)
  `);

  const insertReview = db.prepare(`
    INSERT INTO hygiene_reviews (
      vendor_id, reviewer_name, water_cleanliness, glove_usage,
      covered_food, surroundings, observation, photo, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertPhoto = db.prepare(`
    INSERT INTO vendor_photos (vendor_id, photo_url, caption) VALUES (?, ?, ?)
  `);

  const insertTrail = db.prepare(`
    INSERT INTO food_trails (name, locality, description, estimated_duration) VALUES (?, ?, ?, ?)
  `);

  const insertTrailVendor = db.prepare(`
    INSERT INTO food_trail_vendors (trail_id, vendor_id, sequence_order) VALUES (?, ?, ?)
  `);

  const vendorIdMap = new Map<string, number>();
  let totalReviews = 0;

  const transaction = db.transaction(() => {
    for (const v of SEED_VENDORS) {
      const info = insertVendor.run(
        v.name,
        v.description,
        v.locality,
        v.address,
        v.landmark,
        v.latitude,
        v.longitude,
        v.cuisine,
        v.price_min,
        v.price_max,
        v.opening_time,
        v.closing_time,
        v.image,
        v.fssai_verified,
        v.availability_status,
        v.availability_updated_at,
        v.is_pushcart
      );
      const vendorId = Number(info.lastInsertRowid);
      vendorIdMap.set(v.name, vendorId);

      for (const dish of v.dishes) {
        insertDish.run(vendorId, dish.dish_name, dish.price, dish.description);
      }

      for (const rev of v.reviews) {
        insertReview.run(
          vendorId,
          rev.reviewer_name,
          rev.water_cleanliness,
          rev.glove_usage,
          rev.covered_food,
          rev.surroundings,
          rev.observation,
          '',
          rev.created_at
        );
        totalReviews++;
      }

      insertPhoto.run(vendorId, v.image, `${v.name} signature counter`);
      if (v.fssai_verified === 1 && v.image !== IMAGES.cart) {
        insertPhoto.run(vendorId, IMAGES.cart, 'Clean counter and covered glass display');
      }
    }

    // 4 curated Hyderabad food trails
    const trails = [
      {
        name: 'Top Hygiene Chaat Trail',
        locality: 'Sindhi Colony',
        description:
          'A walking loop through Secunderabad’s cleanest street-food corridor, pairing RO-water pani puri, steamed momos, butter pav bhaji, and ghee dosas.',
        estimated_duration: '75 mins walking',
        stops: [
          'Mahalaxmi Chaat Center',
          'Bombay Express Pav Bhaji',
          'Hyderabad Momos Junction',
          'Secunderabad Sardarji Chaat',
          'Sindhi Colony Ghee Dosa Cart',
        ],
      },
      {
        name: 'Madhapur Evening Byte Trail',
        locality: 'Madhapur',
        description:
          'Tech-corridor evening bites starting near Cyber Towers tiffins and finishing with lakeside pav bhaji and metro-side pani puri.',
        estimated_duration: '60 mins walking & short hop',
        stops: [
          'CyberTowers Clean Tiffins',
          'Popular Pani Puri Stall',
          'Madhapur Spice Momos Hub',
          'Durgam Cheruvu Pav & Chaat',
        ],
      },
      {
        name: 'Charminar Dusk Heritage Trail',
        locality: 'Old City',
        description:
          'Explore historic Pathergatti and Laad Bazaar lanes for crisp cut mirchi bajji, smoky aloo tikki chaat, and classic tamarind golgappa.',
        estimated_duration: '85 mins walking',
        stops: [
          'Old City Chaat Corner',
          'Charminar Nawab Pani Puri',
          'Deccan Mirchi Bajji Hut',
          'Laad Bazaar Mirchi & Chai',
        ],
      },
      {
        name: 'Central Hyderabad Tiffin & Bajji Loop',
        locality: 'Ameerpet & Banjara Hills',
        description:
          'Clean-counter South Indian dosas, metro-side bhel chaat, and Banjara Hills RO-equipped snack carts.',
        estimated_duration: '80 mins transit + walk',
        stops: [
          'Sri Sai Dosa Point',
          'Ameerpet Metro Chaat Express',
          'Royal Hyderabad Snacks Cart',
          'Banjara Spice Pav Bhaji',
        ],
      },
    ];

    for (const trail of trails) {
      const tInfo = insertTrail.run(
        trail.name,
        trail.locality,
        trail.description,
        trail.estimated_duration
      );
      const trailId = Number(tInfo.lastInsertRowid);
      trail.stops.forEach((vendorName, index) => {
        const vid = vendorIdMap.get(vendorName);
        if (vid) {
          insertTrailVendor.run(trailId, vid, index + 1);
        }
      });
    }
  });

  transaction();

  return {
    vendors: SEED_VENDORS.length,
    reviews: totalReviews,
    trails: 4,
  };
}
