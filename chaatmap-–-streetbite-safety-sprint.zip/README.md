# ChaatMap – StreetBite Safety Sprint

**Discover Street Food. Trust the Hygiene.**

ChaatMap is a full-stack, crowd-sourced street food discovery and hygiene-rating web application built for Indian cities (seeded with an illustrative Hyderabad street food dataset). It evaluates stalls using a transparent four-factor sanitation rubric, interactive OpenStreetMap visualizations, food trails with offline guide storage, live availability reporting, and community stall photography.

---

## Key Features

- **Objective Hygiene Trust Score**:
  $$\text{Hygiene Score} = (0.40 \times \text{Water Cleanliness}) + (0.25 \times \text{Covered Food}) + (0.20 \times \text{Glove Usage}) + (0.15 \times \text{Surroundings})$$
- **Vendor Directory**: Search by vendor or dish name, filter by locality, food specialty, minimum hygiene score, or FSSAI status, and sort by hygiene, price, or popularity.
- **Interactive Leaflet + OpenStreetMap**: Custom food-cart markers differentiating FSSAI-verified and unverified stalls, locality cluster mode, nearby GPS sorting, and rich vendor popups.
- **Crowd-Sourced Hygiene Reviews & Photo Uploads**: Interactive 1–5 star ratings for all four sanitation factors with live score preview, image upload validation (JPG/PNG/WebP up to 5MB), and dynamic SQLite recalculation.
- **Food Trails & Offline Guide**: Curated walking loops with sequential Leaflet polyline maps and local browser storage (`localStorage`) for offline viewing.
- **Real-Time Stall Availability**: Community Open/Closed/Unknown status updates with freshness timestamps and pushcart landmark editing.
- **Clean Street Food Vendor of the Month**: Transparently selected from stalls meeting the minimum 3-review threshold.

---

## Technology Stack

- **Frontend (`src/`)**: React 19, React Router, Tailwind CSS v4, Lucide React, Leaflet & React Leaflet (OpenStreetMap tiles)
- **Backend (`backend/` & `server.ts`)**: Node.js, Express.js, Multer, CORS
- **Database**: SQLite via `better-sqlite3`

---

## Local Setup & Startup

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Configuration
Copy `.env.example` to `.env` if customizing port or database path:
```bash
cp .env.example .env
```
Variables:
- `PORT`: Server port (defaults to `3000`)
- `DB_PATH`: SQLite database file path (defaults to `./backend/data/chaatmap.db`)
- `CORS_ORIGIN`: Allowed origins (defaults to `*`)

### 3. Initialize & Seed SQLite Database
The server automatically initializes and seeds the SQLite database on first boot. You can also run the standalone initializer explicitly:
```bash
npm run db:init
```
This populates 20 Hyderabad street food vendors, signature dishes (₹30–₹120), 50 structured hygiene reviews, and 4 curated food trails.

### 4. Start the Full-Stack Application (Backend API + Frontend)
```bash
npm run dev
```
Open `http://localhost:3000` in your browser.

### 5. Build & Production Start
```bash
npm run build
NODE_ENV=production npm start
```

---

## REST API Endpoints

- `GET /api/vendors` — Filter, search, and sort vendors
- `GET /api/vendors/search?q=...` — Search stalls and dishes
- `GET /api/vendors/nearby?lat=...&lng=...&radiusKm=...` — Distance-sorted nearby stalls
- `GET /api/vendors/:id` — Vendor details, dishes, 4-factor breakdown, reviews, and photos
- `GET /api/vendors/:id/reviews` — List hygiene reviews for a vendor
- `POST /api/vendors/:id/reviews` — Submit a structured hygiene review (supports multipart photo upload)
- `PATCH /api/vendors/:id/availability` — Update Open/Closed/Unknown status and pushcart landmark
- `POST /api/vendors/:id/photos` — Upload a community stall photograph
- `GET /api/trails` & `GET /api/trails/:id` — Curated food trails and ordered stops
- `GET /api/featured-vendor` — Clean Street Food Vendor of the Month
- `GET /api/stats` — Live community counts

---

## Transparency & Limitations

- **Seed Dataset & FSSAI Badges**: Seeded vendors and FSSAI indicators are illustrative demonstration records for Hyderabad and do not connect to an official government FSSAI API.
- **Duplicate Review Prevention**: Because ChaatMap runs without mandatory user login accounts, duplicate review prevention is assisted per browser session rather than strictly enforced across devices.
- **Food Trail Map Lines**: Straight dashed lines between trail stops indicate sequence and proximity rather than turn-by-turn pedestrian routing.
